CREATE DATABASE  IF NOT EXISTS `schild_nrw` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `schild_nrw`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 192.168.178.40    Database: schild_nrw
-- ------------------------------------------------------
-- Server version	5.5.62-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AllgAdrAnsprechpartner`
--

DROP TABLE IF EXISTS `AllgAdrAnsprechpartner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AllgAdrAnsprechpartner` (
  `ID` int(11) NOT NULL,
  `Adresse_ID` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Vorname` varchar(30) DEFAULT NULL,
  `Anrede` varchar(10) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL,
  `EMail` varchar(100) DEFAULT NULL,
  `Abteilung` varchar(50) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Titel` varchar(15) DEFAULT NULL,
  `GU_ID` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Ansprechpartner_Adr_FK` (`Adresse_ID`),
  CONSTRAINT `Ansprechpartner_Adr_FK` FOREIGN KEY (`Adresse_ID`) REFERENCES `K_AllgAdresse` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule`
--

DROP TABLE IF EXISTS `EigeneSchule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule` (
  `ID` int(11) DEFAULT NULL,
  `SchulformNr` varchar(4) DEFAULT NULL,
  `SchulformKrz` varchar(4) DEFAULT NULL,
  `SchulformBez` varchar(50) DEFAULT NULL,
  `SchultraegerArt` varchar(4) DEFAULT NULL,
  `SchultraegerNr` varchar(6) DEFAULT NULL,
  `Schulgliederung` varchar(4) DEFAULT NULL,
  `SchulNr` varchar(6) DEFAULT NULL,
  `Bezeichnung1` varchar(50) DEFAULT NULL,
  `Bezeichnung2` varchar(50) DEFAULT NULL,
  `Bezeichnung3` varchar(50) DEFAULT NULL,
  `Strasse` varchar(50) DEFAULT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `Ort` varchar(50) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL,
  `Fax` varchar(20) DEFAULT NULL,
  `EMail` varchar(100) DEFAULT NULL,
  `Ganztags` char(1) DEFAULT '+',
  `Schuljahr` smallint(6) DEFAULT NULL,
  `SchuljahrAbschnitt` smallint(6) DEFAULT NULL,
  `AnzahlAbschnitte` smallint(6) DEFAULT '2',
  `Fremdsprachen` char(1) DEFAULT '+',
  `UpdateSprachenfolge` char(1) DEFAULT '+',
  `JVAZeigen` char(1) DEFAULT '-',
  `RefPaedagogikZeigen` char(1) DEFAULT '-',
  `AnzJGS_Jahr` smallint(6) DEFAULT '1',
  `AbschnittBez` varchar(20) DEFAULT 'Halbjahr',
  `BezAbschnitt1` varchar(10) DEFAULT '1. Hj',
  `BezAbschnitt2` varchar(10) DEFAULT '2. Hj',
  `BezAbschnitt3` varchar(10) DEFAULT NULL,
  `BezAbschnitt4` varchar(10) DEFAULT NULL,
  `IstHauptsitz` char(1) DEFAULT '+',
  `NotenGesperrt` char(1) DEFAULT '-',
  `ZurueckgestelltAnzahl` int(11) DEFAULT NULL,
  `ZurueckgestelltWeibl` int(11) DEFAULT NULL,
  `ZurueckgestelltAuslaender` int(11) DEFAULT NULL,
  `ZurueckgestelltAuslaenderWeibl` int(11) DEFAULT NULL,
  `ZurueckgestelltAussiedler` int(11) DEFAULT NULL,
  `ZurueckgestelltAussiedlerWeibl` int(11) DEFAULT NULL,
  `TeamTeaching` varchar(1) DEFAULT NULL,
  `AbiGruppenprozess` varchar(1) DEFAULT NULL,
  `DauerUnterrichtseinheit` int(11) DEFAULT NULL,
  `Gruppen8Bis1` int(11) DEFAULT NULL,
  `Gruppen13Plus` int(11) DEFAULT NULL,
  `InternatsplaetzeM` int(11) DEFAULT NULL,
  `InternatsplaetzeW` int(11) DEFAULT NULL,
  `InternatsplaetzeNeutral` int(11) DEFAULT NULL,
  `SchulLogo` mediumblob,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `SchulleiterName` varchar(50) DEFAULT NULL,
  `SchulleiterVorname` varchar(30) DEFAULT NULL,
  `SchulleiterAmtsbez` varchar(30) DEFAULT NULL,
  `SchulleiterGeschlecht` int(11) DEFAULT NULL,
  `StvSchulleiterName` varchar(50) DEFAULT NULL,
  `StvSchulleiterVorname` varchar(30) DEFAULT NULL,
  `StvSchulleiterAmtsbez` varchar(30) DEFAULT NULL,
  `StvSchulleiterGeschlecht` int(11) DEFAULT NULL,
  `Einstellungen` text,
  `Fehlstundenmodell_PrS1` varchar(1) DEFAULT 'G',
  `Fehlstundenmodell_S2` varchar(1) DEFAULT 'F',
  `Tendenznoten_S1` varchar(1) DEFAULT '-',
  `WebKL_Modus` varchar(1) DEFAULT 'A',
  `WebMahnungenGesperrt` varchar(1) DEFAULT '-',
  `WebNotenGesperrt` varchar(1) DEFAULT '-',
  `LogoFormat` varchar(3) DEFAULT NULL,
  `SchILDweb_Config` text,
  `WebTeilLeistungenAnlegen` varchar(1) DEFAULT '-',
  `WebInfoMail` varchar(1) DEFAULT '-',
  `WebAdresse` varchar(100) DEFAULT NULL,
  `Land` varchar(50) DEFAULT NULL,
  `Einstellungen2` text,
  `SchulleiterTitel` varchar(10) DEFAULT NULL,
  `StvSchulleiterTitel` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Abt_Kl`
--

DROP TABLE IF EXISTS `EigeneSchule_Abt_Kl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Abt_Kl` (
  `ID` int(11) NOT NULL,
  `Abteilung_ID` int(11) NOT NULL,
  `Klasse` varchar(15) NOT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Abt_Kl_IX1` (`Abteilung_ID`,`Klasse`),
  KEY `Abteilung_ID_IX` (`Abteilung_ID`),
  KEY `Klasse_IX` (`Klasse`),
  CONSTRAINT `EigeneSchule_Abt_Kl_ibfk_1` FOREIGN KEY (`Abteilung_ID`) REFERENCES `EigeneSchule_Abteilungen` (`ID`),
  CONSTRAINT `EigeneSchule_Abt_Kl_ibfk_2` FOREIGN KEY (`Klasse`) REFERENCES `Versetzung` (`Klasse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Abteilungen`
--

DROP TABLE IF EXISTS `EigeneSchule_Abteilungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Abteilungen` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `AbteilungsLeiter` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Raum` varchar(20) DEFAULT NULL,
  `EMail` varchar(100) DEFAULT NULL,
  `Durchwahl` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `AbteilungsLeiter_IX` (`AbteilungsLeiter`),
  CONSTRAINT `EigeneSchule_Abteilungen_ibfk_1` FOREIGN KEY (`AbteilungsLeiter`) REFERENCES `K_Lehrer` (`Kuerzel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_FachTeilleistungen`
--

DROP TABLE IF EXISTS `EigeneSchule_FachTeilleistungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_FachTeilleistungen` (
  `SchulnrEigner` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `Teilleistung_ID` int(11) NOT NULL,
  `Kursart` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`SchulnrEigner`,`Fach_ID`,`Teilleistung_ID`,`Kursart`),
  KEY `EigeneSchule_FachTeilleistungen_Fach_FK` (`Fach_ID`),
  CONSTRAINT `EigeneSchule_FachTeilleistungen_Fach_FK` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Fachklassen`
--

DROP TABLE IF EXISTS `EigeneSchule_Fachklassen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Fachklassen` (
  `ID` int(11) NOT NULL,
  `BKIndex` smallint(6) DEFAULT NULL,
  `FKS` varchar(4) DEFAULT NULL,
  `AP` varchar(4) DEFAULT NULL,
  `Bezeichnung` varchar(100) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `Kennung` varchar(10) DEFAULT NULL,
  `FKS_AP_SIM` varchar(5) DEFAULT NULL,
  `BKIndexTyp` varchar(4) DEFAULT NULL,
  `Beschreibung_W` varchar(100) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Lernfelder` text,
  `DQR_Niveau` int(11) DEFAULT NULL,
  `Ebene1Klartext` varchar(255) DEFAULT NULL,
  `Ebene2Klartext` varchar(255) DEFAULT NULL,
  `Ebene3Klartext` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Fachklassen_IDX1` (`BKIndexTyp`,`FKS`,`AP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Faecher`
--

DROP TABLE IF EXISTS `EigeneSchule_Faecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Faecher` (
  `ID` int(11) NOT NULL,
  `FachKrz` varchar(20) DEFAULT NULL,
  `Bezeichnung` varchar(255) DEFAULT NULL,
  `Zeugnisbez` varchar(255) DEFAULT NULL,
  `UeZeugnisbez` varchar(255) DEFAULT NULL,
  `StatistikKrz` varchar(4) DEFAULT NULL,
  `BasisFach` varchar(4) DEFAULT NULL,
  `IstSprache` char(1) DEFAULT '-',
  `Sortierung` smallint(6) DEFAULT '32000',
  `SortierungS2` smallint(6) DEFAULT '32000',
  `NachprErlaubt` char(1) DEFAULT '+',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `Gewichtung` smallint(6) DEFAULT '1',
  `Unterichtssprache` char(1) DEFAULT 'D',
  `Fachgruppe_ID` int(11) DEFAULT NULL,
  `IstSchriftlich` char(1) DEFAULT '-',
  `IstSchriftlichBA` char(1) DEFAULT '-',
  `AufZeugnis` varchar(1) DEFAULT '+',
  `Lernfelder` text,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `LK_Moegl` varchar(1) DEFAULT NULL,
  `Abi_Moegl` varchar(1) DEFAULT NULL,
  `E1` varchar(1) DEFAULT NULL,
  `E2` varchar(1) DEFAULT NULL,
  `Q1` varchar(1) DEFAULT NULL,
  `Q2` varchar(1) DEFAULT NULL,
  `Q3` varchar(1) DEFAULT NULL,
  `Q4` varchar(1) DEFAULT NULL,
  `AlsNeueFSinSII` varchar(1) DEFAULT NULL,
  `Leitfach_ID` int(11) DEFAULT NULL,
  `Leitfach2_ID` int(11) DEFAULT NULL,
  `Aufgabenfeld` varchar(2) DEFAULT NULL,
  `AbgeschlFaecherHolen` varchar(1) DEFAULT '+',
  `GewichtungFHR` int(11) DEFAULT NULL,
  `E1_WZE` int(11) DEFAULT NULL,
  `E2_WZE` int(11) DEFAULT NULL,
  `Q_WZE` int(11) DEFAULT NULL,
  `E1_S` varchar(1) DEFAULT '-',
  `E2_S` varchar(1) DEFAULT '-',
  `NurMuendlich` varchar(1) DEFAULT '-',
  `MaxBemZeichen` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Faecher_IDX1` (`FachKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Jahrgaenge`
--

DROP TABLE IF EXISTS `EigeneSchule_Jahrgaenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Jahrgaenge` (
  `ID` int(11) NOT NULL,
  `InternKrz` varchar(20) DEFAULT NULL,
  `ASDJahrgang` varchar(4) DEFAULT NULL,
  `ASDBezeichnung` varchar(100) DEFAULT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `Sortierung` smallint(6) DEFAULT '32000',
  `IstChronologisch` char(1) DEFAULT '+',
  `Spaltentitel` varchar(4) DEFAULT NULL,
  `SekStufe` varchar(6) DEFAULT NULL,
  `SGL` varchar(4) DEFAULT NULL,
  `JahrgangNum` smallint(6) DEFAULT NULL,
  `Restabschnitte` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Folgejahrgang_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Jahrgaenge_IDX1` (`InternKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_KAoADaten`
--

DROP TABLE IF EXISTS `EigeneSchule_KAoADaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_KAoADaten` (
  `SchulnrEigner` int(11) NOT NULL,
  `Curriculum` varchar(1) DEFAULT '+',
  `Koordinator` varchar(1) DEFAULT '+',
  `Berufsorientierungsbuero` varchar(1) DEFAULT '+',
  `KooperationsvereinbarungAA` varchar(1) DEFAULT '+',
  `NutzungReflexionsworkshop` varchar(1) DEFAULT '+',
  `NutzungEntscheidungskompetenzI` varchar(1) DEFAULT '+',
  `NutzungEntscheidungskompetenzII` varchar(1) DEFAULT '+'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Kursart`
--

DROP TABLE IF EXISTS `EigeneSchule_Kursart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Kursart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(120) DEFAULT NULL,
  `InternBez` varchar(20) DEFAULT NULL,
  `Kursart` varchar(5) DEFAULT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Kursart_IDX1` (`Kursart`,`KursartAllg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_KursartAllg`
--

DROP TABLE IF EXISTS `EigeneSchule_KursartAllg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_KursartAllg` (
  `ID` int(11) NOT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `InternBez` varchar(20) DEFAULT NULL,
  `KursartASD` varchar(4) DEFAULT NULL,
  `Bezeichnung` varchar(120) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_KursartAllg_IDX1` (`KursartAllg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Merkmale`
--

DROP TABLE IF EXISTS `EigeneSchule_Merkmale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Merkmale` (
  `ID` int(11) NOT NULL,
  `Schule` varchar(1) DEFAULT NULL,
  `Schueler` varchar(1) DEFAULT NULL,
  `Kurztext` varchar(10) NOT NULL DEFAULT '',
  `Langtext` varchar(100) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Kurztext`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Schulformen`
--

DROP TABLE IF EXISTS `EigeneSchule_Schulformen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Schulformen` (
  `ID` int(11) NOT NULL,
  `SGL` varchar(4) NOT NULL,
  `SF_SGL` varchar(5) DEFAULT NULL,
  `Schulform` varchar(100) DEFAULT NULL,
  `DoppelQualifikation` char(1) DEFAULT '-',
  `BKIndex` smallint(6) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Schulform2` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SGL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Teilstandorte`
--

DROP TABLE IF EXISTS `EigeneSchule_Teilstandorte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Teilstandorte` (
  `SchulnrEigner` int(11) NOT NULL,
  `AdrMerkmal` varchar(1) NOT NULL DEFAULT '',
  `PLZ` varchar(10) DEFAULT NULL,
  `Ort` varchar(50) DEFAULT NULL,
  `Strasse` varchar(50) DEFAULT NULL,
  `Hausnr` varchar(10) DEFAULT NULL,
  `Bemerkung` varchar(50) DEFAULT NULL,
  `Kuerzel` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`SchulnrEigner`,`AdrMerkmal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Texte`
--

DROP TABLE IF EXISTS `EigeneSchule_Texte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Texte` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Kuerzel` varchar(50) DEFAULT NULL,
  `Inhalt` varchar(255) DEFAULT NULL,
  `Beschreibung` varchar(100) DEFAULT NULL,
  `Aenderbar` varchar(1) DEFAULT '+',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Zertifikate`
--

DROP TABLE IF EXISTS `EigeneSchule_Zertifikate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Zertifikate` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Kuerzel` varchar(20) NOT NULL,
  `Bezeichnung` varchar(100) DEFAULT NULL,
  `Fach` varchar(100) DEFAULT NULL,
  `Formatvorlage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `EigeneSchule_Zertifikate_IX1` (`SchulnrEigner`,`Kuerzel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `EigeneSchule_Zertifikatsfaecher`
--

DROP TABLE IF EXISTS `EigeneSchule_Zertifikatsfaecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EigeneSchule_Zertifikatsfaecher` (
  `Zertifikat_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Kuerzel` varchar(20) NOT NULL,
  `Klartext` varchar(100) DEFAULT NULL,
  `Lernfelder` text,
  `MaxPunkte` int(11) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  PRIMARY KEY (`SchulnrEigner`,`Kuerzel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Fach_Gliederungen`
--

DROP TABLE IF EXISTS `Fach_Gliederungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Fach_Gliederungen` (
  `Fach_ID` int(11) NOT NULL,
  `Gliederung` varchar(3) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Faechergruppe` int(11) DEFAULT NULL,
  `GewichtungAB` int(11) DEFAULT NULL,
  `GewichtungBB` int(11) DEFAULT NULL,
  `SchriftlichAB` varchar(1) DEFAULT NULL,
  `SchriftlichBB` varchar(1) DEFAULT NULL,
  `GymOSFach` varchar(1) DEFAULT NULL,
  `ZeugnisBez` varchar(130) DEFAULT NULL,
  `Lernfelder` text,
  `Fachklasse_ID` int(11) NOT NULL DEFAULT '0',
  `Sortierung` int(11) DEFAULT '32000',
  PRIMARY KEY (`Fach_ID`,`Gliederung`,`Fachklasse_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Fachklassen_Schwerpunkte`
--

DROP TABLE IF EXISTS `Fachklassen_Schwerpunkte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Fachklassen_Schwerpunkte` (
  `SchulnrEigner` int(11) NOT NULL,
  `Fachklasse_ID` int(11) NOT NULL,
  `Schwerpunkt_ID` int(11) NOT NULL,
  PRIMARY KEY (`SchulnrEigner`,`Fachklasse_ID`,`Schwerpunkt_ID`),
  KEY `Fachklassen_Schwerpunkte_Fachkl_FK` (`Fachklasse_ID`),
  KEY `Fachklassen_Schwerpunkte_Schwerp_FK` (`Schwerpunkt_ID`),
  CONSTRAINT `Fachklassen_Schwerpunkte_Fachkl_FK` FOREIGN KEY (`Fachklasse_ID`) REFERENCES `EigeneSchule_Fachklassen` (`ID`),
  CONSTRAINT `Fachklassen_Schwerpunkte_Schwerp_FK` FOREIGN KEY (`Schwerpunkt_ID`) REFERENCES `K_Schwerpunkt` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Floskelgruppen`
--

DROP TABLE IF EXISTS `Floskelgruppen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Floskelgruppen` (
  `SchulnrEigner` int(11) NOT NULL,
  `Kuerzel` varchar(4) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Hauptgruppe` varchar(4) DEFAULT NULL,
  `Farbe` int(11) DEFAULT NULL,
  PRIMARY KEY (`SchulnrEigner`,`Kuerzel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Floskeln`
--

DROP TABLE IF EXISTS `Floskeln`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Floskeln` (
  `SchulnrEigner` int(11) NOT NULL,
  `Kuerzel` varchar(10) NOT NULL,
  `Floskeltext` text NOT NULL,
  `Floskelgruppe` varchar(10) NOT NULL DEFAULT '',
  `Floskelfach` varchar(20) DEFAULT NULL,
  `Floskelniveau` varchar(2) DEFAULT NULL,
  `Floskeljahrgang` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`SchulnrEigner`,`Floskelgruppe`,`Kuerzel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Adressart`
--

DROP TABLE IF EXISTS `K_Adressart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Adressart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Adressart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_AllgAdresse`
--

DROP TABLE IF EXISTS `K_AllgAdresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_AllgAdresse` (
  `ID` int(11) NOT NULL,
  `AllgAdrAdressart` varchar(30) NOT NULL,
  `AllgAdrName1` varchar(50) DEFAULT NULL,
  `AllgAdrName2` varchar(50) DEFAULT NULL,
  `AllgAdrStrasse` varchar(50) DEFAULT NULL,
  `AllgAdrPLZ` varchar(10) DEFAULT NULL,
  `AllgAdrTelefon1` varchar(20) DEFAULT NULL,
  `AllgAdrTelefon2` varchar(20) DEFAULT NULL,
  `AllgAdrFax` varchar(20) DEFAULT NULL,
  `AllgAdrEmail` varchar(100) DEFAULT NULL,
  `AllgAdrBemerkungen` varchar(255) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `AllgAdrAusbildungsBetrieb` char(1) DEFAULT '-',
  `AllgAdrBietetPraktika` char(1) DEFAULT '-',
  `AllgAdrBranche` varchar(50) DEFAULT NULL,
  `AllgAdrZusatz1` varchar(10) DEFAULT NULL,
  `AllgAdrZusatz2` varchar(10) DEFAULT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Massnahmentraeger` varchar(1) DEFAULT '-',
  `BelehrungISG` varchar(1) DEFAULT '-',
  `GU_ID` varchar(40) DEFAULT NULL,
  `ErwFuehrungszeugnis` varchar(1) DEFAULT '-',
  `ExtID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `AllgAdrAdressart_IX` (`AllgAdrAdressart`),
  CONSTRAINT `K_AllgAdresse_Adressart_FK` FOREIGN KEY (`AllgAdrAdressart`) REFERENCES `K_Adressart` (`Bezeichnung`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `K_AllgAdresse_ibfk_1` FOREIGN KEY (`AllgAdrAdressart`) REFERENCES `K_Adressart` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Ankreuzdaten`
--

DROP TABLE IF EXISTS `K_Ankreuzdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Ankreuzdaten` (
  `SchulnrEigner` int(11) NOT NULL,
  `TextStufe1` varchar(100) DEFAULT NULL,
  `TextStufe2` varchar(100) DEFAULT NULL,
  `TextStufe3` varchar(100) DEFAULT NULL,
  `TextStufe4` varchar(100) DEFAULT NULL,
  `TextStufe5` varchar(100) DEFAULT NULL,
  `BezeichnungSONST` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`SchulnrEigner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Ankreuzfloskeln`
--

DROP TABLE IF EXISTS `K_Ankreuzfloskeln`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Ankreuzfloskeln` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SchulnrEigner` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `Jahrgang` varchar(2) NOT NULL,
  `Floskeltext` varchar(255) NOT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `FachSortierung` int(11) DEFAULT NULL,
  `Abschnitt` int(11) DEFAULT NULL,
  `Aktiv` varchar(1) DEFAULT NULL,
  `Gliederung` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Beschaeftigungsart`
--

DROP TABLE IF EXISTS `K_Beschaeftigungsart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Beschaeftigungsart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(100) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Beschaeftigungsart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Datenschutz`
--

DROP TABLE IF EXISTS `K_Datenschutz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Datenschutz` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Bezeichnung` varchar(250) DEFAULT NULL,
  `Sichtbar` varchar(1) DEFAULT '+',
  `Schluessel` varchar(20) DEFAULT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `Beschreibung` text,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Einschulungsart`
--

DROP TABLE IF EXISTS `K_Einschulungsart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Einschulungsart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(40) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Einschulungsart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Einzelleistungen`
--

DROP TABLE IF EXISTS `K_Einzelleistungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Einzelleistungen` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Bezeichnung` varchar(50) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT '32000',
  `Sichtbar` varchar(1) DEFAULT NULL,
  `Gewichtung` float DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Entlassgrund`
--

DROP TABLE IF EXISTS `K_Entlassgrund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Entlassgrund` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Entlassgrund_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Erzieherart`
--

DROP TABLE IF EXISTS `K_Erzieherart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Erzieherart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `ExportBez` varchar(20) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Erzieherart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Erzieherfunktion`
--

DROP TABLE IF EXISTS `K_Erzieherfunktion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Erzieherfunktion` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Erzieherfunktion_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Fahrschuelerart`
--

DROP TABLE IF EXISTS `K_Fahrschuelerart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Fahrschuelerart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Fahrschuelerart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Foerderschwerpunkt`
--

DROP TABLE IF EXISTS `K_Foerderschwerpunkt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Foerderschwerpunkt` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `StatistikKrz` varchar(4) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Foerderschwerpunkt_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Haltestelle`
--

DROP TABLE IF EXISTS `K_Haltestelle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Haltestelle` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `EntfernungSchule` float DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Haltestelle_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Kindergarten`
--

DROP TABLE IF EXISTS `K_Kindergarten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Kindergarten` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) DEFAULT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `Ort` varchar(30) DEFAULT NULL,
  `Strasse` varchar(40) DEFAULT NULL,
  `Tel` varchar(20) DEFAULT NULL,
  `EMail` varchar(40) DEFAULT NULL,
  `Bemerkung` varchar(50) DEFAULT NULL,
  `Sichtbar` varchar(1) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_KlassenOrgform`
--

DROP TABLE IF EXISTS `K_KlassenOrgform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_KlassenOrgform` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(100) NOT NULL,
  `StatistikKrz` varchar(4) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_KlassenOrgform_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Lehrer`
--

DROP TABLE IF EXISTS `K_Lehrer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Lehrer` (
  `ID` int(11) NOT NULL,
  `Kuerzel` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `LIDKrz` varchar(4) DEFAULT NULL,
  `Nachname` varchar(30) NOT NULL,
  `Vorname` varchar(20) DEFAULT NULL,
  `Anrede` varchar(10) DEFAULT NULL,
  `Titel` varchar(20) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `Geburtsdatum` datetime DEFAULT NULL,
  `Geschlecht` varchar(1) DEFAULT NULL,
  `SerNr` varchar(5) DEFAULT NULL,
  `StaatKrz` varchar(3) DEFAULT NULL,
  `Rechtsverhaeltnis` varchar(1) DEFAULT NULL,
  `Beschaeftigungsart` varchar(2) DEFAULT NULL,
  `Einsatzstatus` varchar(1) DEFAULT NULL,
  `PflichtstdSoll` float DEFAULT NULL,
  `UnterrichtsStd` float DEFAULT NULL,
  `Strasse` varchar(50) DEFAULT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `Tel` varchar(20) DEFAULT NULL,
  `Handy` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Statistik` varchar(1) DEFAULT NULL,
  `StammschulNr` varchar(6) DEFAULT NULL,
  `DatumZugang` datetime DEFAULT NULL,
  `DatumAbgang` datetime DEFAULT NULL,
  `GrundZugang` varchar(10) DEFAULT NULL,
  `GrundAbgang` varchar(10) DEFAULT NULL,
  `SchulFunktion` varchar(10) DEFAULT NULL,
  `MehrleistungStd` float DEFAULT NULL,
  `EntlastungStd` float DEFAULT NULL,
  `AnrechnungStd` float DEFAULT NULL,
  `RestStd` float DEFAULT NULL,
  `Amtsbezeichnung` varchar(15) DEFAULT NULL,
  `IdentNr1` varchar(10) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `GU_ID` varchar(40) DEFAULT NULL,
  `Faecher` varchar(100) DEFAULT NULL,
  `FuerExport` varchar(1) DEFAULT '+',
  `PersonTyp` varchar(20) DEFAULT 'LEHRKRAFT',
  `LPassword` varchar(255) DEFAULT NULL,
  `PWAktuell` varchar(3) DEFAULT '-;5',
  `SchILDweb_FL` varchar(1) DEFAULT '+',
  `SchILDweb_KL` varchar(1) DEFAULT '+',
  `SchILDweb_Config` text,
  `EMailDienstlich` varchar(100) DEFAULT NULL,
  `KennwortTools` varchar(255) DEFAULT NULL,
  `Antwort1` varchar(255) DEFAULT NULL,
  `Antwort2` varchar(255) DEFAULT NULL,
  `PANr` varchar(20) DEFAULT NULL,
  `LBVNr` varchar(15) DEFAULT NULL,
  `VSchluessel` varchar(1) DEFAULT NULL,
  `KennwortToolsAktuell` varchar(1) DEFAULT NULL,
  `MasernImpfnachweis` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Lehrer_IDX1` (`Kuerzel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Ort`
--

DROP TABLE IF EXISTS `K_Ort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Ort` (
  `ID` int(11) NOT NULL,
  `PLZ` varchar(10) NOT NULL,
  `Bezeichnung` varchar(50) DEFAULT NULL,
  `Kreis` varchar(4) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '3200',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `Land` varchar(2) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Ort_IDX1` (`PLZ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Ortsteil`
--

DROP TABLE IF EXISTS `K_Ortsteil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Ortsteil` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `OrtsteilSchluessel` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Religion`
--

DROP TABLE IF EXISTS `K_Religion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Religion` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `StatistikKrz` varchar(10) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `ExportBez` varchar(20) DEFAULT NULL,
  `ZeugnisBezeichnung` varchar(50) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Religion_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Schule`
--

DROP TABLE IF EXISTS `K_Schule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Schule` (
  `ID` int(11) NOT NULL,
  `SchulNr` varchar(6) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `SchulformNr` varchar(4) DEFAULT NULL,
  `SchulformKrz` varchar(4) DEFAULT NULL,
  `SchulformBez` varchar(50) DEFAULT NULL,
  `Strasse` varchar(50) DEFAULT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `Ort` varchar(50) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL,
  `Fax` varchar(20) DEFAULT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `Schulleiter` varchar(40) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulNr_SIM` varchar(6) DEFAULT NULL,
  `Kuerzel` varchar(10) DEFAULT NULL,
  `KurzBez` varchar(40) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Schule_IDX1` (`SchulNr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Schulfunktionen`
--

DROP TABLE IF EXISTS `K_Schulfunktionen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Schulfunktionen` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `Sichtbar` varchar(1) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Schwerpunkt`
--

DROP TABLE IF EXISTS `K_Schwerpunkt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Schwerpunkt` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Schwerpunkt_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Sportbefreiung`
--

DROP TABLE IF EXISTS `K_Sportbefreiung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Sportbefreiung` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Sportbefreiung_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Staat`
--

DROP TABLE IF EXISTS `K_Staat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Staat` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(80) NOT NULL,
  `StatistikKrz` varchar(4) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `ExportBez` varchar(20) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Bezeichnung2` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Staat_IDX1` (`StatistikKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Telefonart`
--

DROP TABLE IF EXISTS `K_Telefonart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Telefonart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Telefonart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Verkehrssprachen`
--

DROP TABLE IF EXISTS `K_Verkehrssprachen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Verkehrssprachen` (
  `ID` int(11) NOT NULL,
  `Kurztext` varchar(10) NOT NULL DEFAULT '',
  `Langtext` varchar(100) DEFAULT NULL,
  `Sichtbar` varchar(1) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Kurztext`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Vermerkart`
--

DROP TABLE IF EXISTS `K_Vermerkart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Vermerkart` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(30) NOT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Aenderbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `K_Vermerkart_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `K_Zertifikate`
--

DROP TABLE IF EXISTS `K_Zertifikate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `K_Zertifikate` (
  `Kuerzel` varchar(5) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  PRIMARY KEY (`Kuerzel`,`SchulnrEigner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Kompetenzen`
--

DROP TABLE IF EXISTS `Kompetenzen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Kompetenzen` (
  `KO_ID` int(11) NOT NULL,
  `KO_Gruppe` int(11) NOT NULL,
  `KO_Bezeichnung` varchar(64) NOT NULL,
  PRIMARY KEY (`KO_ID`,`KO_Gruppe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Kompetenzgruppen`
--

DROP TABLE IF EXISTS `Kompetenzgruppen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Kompetenzgruppen` (
  `KG_Spalte` int(11) NOT NULL,
  `KG_Zeile` int(11) NOT NULL,
  `KG_ID` int(11) NOT NULL,
  `KG_Bezeichnung` varchar(50) NOT NULL,
  PRIMARY KEY (`KG_Spalte`,`KG_Zeile`,`KG_ID`,`KG_Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `KursKombinationen`
--

DROP TABLE IF EXISTS `KursKombinationen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KursKombinationen` (
  `Kurs1_ID` int(11) NOT NULL,
  `Kurs2_ID` int(11) NOT NULL,
  PRIMARY KEY (`Kurs1_ID`,`Kurs2_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `KursLehrer`
--

DROP TABLE IF EXISTS `KursLehrer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `KursLehrer` (
  `Kurs_ID` int(11) NOT NULL,
  `Lehrer_ID` int(11) NOT NULL,
  `Anteil` float DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Kurs_ID`,`Lehrer_ID`),
  KEY `KursLehrer_Lehrer_FK` (`Lehrer_ID`),
  CONSTRAINT `KursLehrer_Kurs_FK` FOREIGN KEY (`Kurs_ID`) REFERENCES `Kurse` (`ID`),
  CONSTRAINT `KursLehrer_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Kurse`
--

DROP TABLE IF EXISTS `Kurse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Kurse` (
  `ID` int(11) NOT NULL,
  `Jahr` smallint(6) NOT NULL,
  `Abschnitt` smallint(6) NOT NULL,
  `KurzBez` varchar(20) NOT NULL,
  `Jahrgang_ID` int(11) DEFAULT NULL,
  `ASDJahrgang` varchar(4) DEFAULT NULL,
  `Fach_ID` int(11) NOT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `Wochenstd` smallint(6) DEFAULT NULL,
  `LehrerKrz` varchar(10) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Schienen` varchar(20) DEFAULT NULL,
  `Fortschreibungsart` varchar(1) DEFAULT NULL,
  `WochenstdKL` float DEFAULT NULL,
  `Schulnr` int(11) DEFAULT NULL,
  `EpochU` varchar(1) DEFAULT '-',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Zeugnisbez` varchar(130) DEFAULT NULL,
  `Jahrgaenge` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Kurse_IDX1` (`Jahr`,`Abschnitt`,`KurzBez`,`Fach_ID`,`ASDJahrgang`,`KursartAllg`,`Wochenstd`,`LehrerKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerAbschnittsdaten`
--

DROP TABLE IF EXISTS `LehrerAbschnittsdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerAbschnittsdaten` (
  `Lehrer_ID` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL,
  `Abschnitt` int(11) NOT NULL,
  `Rechtsverhaeltnis` varchar(1) DEFAULT NULL,
  `Beschaeftigungsart` varchar(2) DEFAULT NULL,
  `Einsatzstatus` varchar(1) DEFAULT NULL,
  `PflichtstdSoll` float DEFAULT NULL,
  `UnterrichtsStd` float DEFAULT NULL,
  `MehrleistungStd` float DEFAULT NULL,
  `EntlastungStd` float DEFAULT NULL,
  `AnrechnungStd` float DEFAULT NULL,
  `RestStd` float DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`Jahr`,`Abschnitt`),
  CONSTRAINT `LehrerAbschnitte_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerAnrechnung`
--

DROP TABLE IF EXISTS `LehrerAnrechnung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerAnrechnung` (
  `Lehrer_ID` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL,
  `Abschnitt` int(11) NOT NULL,
  `AnrechnungsgrundKrz` varchar(10) NOT NULL DEFAULT '',
  `AnrechnungStd` float DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`AnrechnungsgrundKrz`,`Jahr`,`Abschnitt`),
  CONSTRAINT `LehrerAnrechnung_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerEntlastung`
--

DROP TABLE IF EXISTS `LehrerEntlastung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerEntlastung` (
  `Lehrer_ID` int(11) NOT NULL,
  `EntlastungsgrundKrz` varchar(10) NOT NULL DEFAULT '',
  `EntlastungStd` float DEFAULT NULL,
  `Jahr` int(11) NOT NULL DEFAULT '0',
  `Abschnitt` int(11) NOT NULL DEFAULT '0',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`EntlastungsgrundKrz`,`Jahr`,`Abschnitt`),
  CONSTRAINT `LehrerEntlastung_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerFotos`
--

DROP TABLE IF EXISTS `LehrerFotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerFotos` (
  `Lehrer_ID` int(11) NOT NULL,
  `Foto` mediumblob,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerFunktionen`
--

DROP TABLE IF EXISTS `LehrerFunktionen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerFunktionen` (
  `Lehrer_ID` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL DEFAULT '0',
  `Abschnitt` int(11) NOT NULL,
  `Funktion_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`Jahr`,`Abschnitt`,`Funktion_ID`),
  KEY `LehrerFunktionen_Funktion_FK` (`Funktion_ID`),
  CONSTRAINT `LehrerFunktionen_Funktion_FK` FOREIGN KEY (`Funktion_ID`) REFERENCES `K_Schulfunktionen` (`ID`),
  CONSTRAINT `LehrerFunktionen_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerLehramt`
--

DROP TABLE IF EXISTS `LehrerLehramt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerLehramt` (
  `Lehrer_ID` int(11) NOT NULL,
  `LehramtKrz` varchar(10) NOT NULL DEFAULT '',
  `LehramtAnerkennungKrz` varchar(10) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`LehramtKrz`),
  CONSTRAINT `LehrerLehramt_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerLehramtFachr`
--

DROP TABLE IF EXISTS `LehrerLehramtFachr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerLehramtFachr` (
  `Lehrer_ID` int(11) NOT NULL,
  `LehramtKrz` varchar(10) NOT NULL DEFAULT '',
  `FachrKrz` varchar(10) NOT NULL DEFAULT '',
  `FachrAnerkennungKrz` varchar(10) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`LehramtKrz`,`FachrKrz`),
  CONSTRAINT `LehramtFachr_FK` FOREIGN KEY (`Lehrer_ID`, `LehramtKrz`) REFERENCES `LehrerLehramt` (`Lehrer_ID`, `LehramtKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerLehramtLehrbef`
--

DROP TABLE IF EXISTS `LehrerLehramtLehrbef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerLehramtLehrbef` (
  `Lehrer_ID` int(11) NOT NULL,
  `LehramtKrz` varchar(10) NOT NULL DEFAULT '',
  `LehrbefKrz` varchar(10) NOT NULL DEFAULT '',
  `LehrbefAnerkennungKrz` varchar(10) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`LehramtKrz`,`LehrbefKrz`),
  CONSTRAINT `LehramtLehrbef_FK` FOREIGN KEY (`Lehrer_ID`, `LehramtKrz`) REFERENCES `LehrerLehramt` (`Lehrer_ID`, `LehramtKrz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `LehrerMehrleistung`
--

DROP TABLE IF EXISTS `LehrerMehrleistung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LehrerMehrleistung` (
  `Lehrer_ID` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL,
  `Abschnitt` int(11) NOT NULL,
  `MehrleistungsgrundKrz` varchar(10) NOT NULL DEFAULT '',
  `MehrleistungStd` float DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Lehrer_ID`,`MehrleistungsgrundKrz`,`Jahr`,`Abschnitt`),
  CONSTRAINT `LehrerMehrleistung_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Lehrer_IMEI`
--

DROP TABLE IF EXISTS `Lehrer_IMEI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Lehrer_IMEI` (
  `ID` int(11) NOT NULL,
  `Lehrer_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `IMEI` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Lehrer_IMEI_Lehrer_FK` (`Lehrer_ID`),
  CONSTRAINT `Lehrer_IMEI_Lehrer_FK` FOREIGN KEY (`Lehrer_ID`) REFERENCES `K_Lehrer` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Logins`
--

DROP TABLE IF EXISTS `Logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Logins` (
  `LI_UserID` int(11) NOT NULL,
  `LI_LoginTime` datetime DEFAULT NULL,
  `LI_LogOffTime` datetime DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `NichtMoeglAbiFachKombi`
--

DROP TABLE IF EXISTS `NichtMoeglAbiFachKombi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NichtMoeglAbiFachKombi` (
  `Fach1_ID` int(11) NOT NULL,
  `Fach2_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Kursart1` varchar(5) DEFAULT NULL,
  `Kursart2` varchar(5) DEFAULT NULL,
  `PK` varchar(30) NOT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `Phase` varchar(10) DEFAULT NULL,
  `Typ` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`PK`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Personengruppen`
--

DROP TABLE IF EXISTS `Personengruppen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Personengruppen` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Gruppenname` varchar(100) NOT NULL,
  `Zusatzinfo` varchar(100) DEFAULT NULL,
  `SammelEMail` varchar(100) DEFAULT NULL,
  `GruppenArt` varchar(20) DEFAULT NULL,
  `XMLExport` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Personengruppen_Personen`
--

DROP TABLE IF EXISTS `Personengruppen_Personen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Personengruppen_Personen` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Gruppe_ID` int(11) NOT NULL,
  `Person_ID` int(11) DEFAULT NULL,
  `PersonNr` int(11) DEFAULT NULL,
  `PersonArt` varchar(1) DEFAULT NULL,
  `PersonName` varchar(50) NOT NULL,
  `PersonVorname` varchar(30) DEFAULT NULL,
  `PersonPLZ` varchar(10) DEFAULT NULL,
  `PersonOrt` varchar(50) DEFAULT NULL,
  `PersonStrasse` varchar(50) DEFAULT NULL,
  `PersonTelefon` varchar(20) DEFAULT NULL,
  `PersonMobil` varchar(20) DEFAULT NULL,
  `PersonEMail` varchar(100) DEFAULT NULL,
  `Bemerkung` varchar(100) DEFAULT NULL,
  `ZusatzInfo` varchar(100) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `PersonAnrede` varchar(10) DEFAULT NULL,
  `PersonAkadGrad` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `PrfSemAbschl`
--

DROP TABLE IF EXISTS `PrfSemAbschl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PrfSemAbschl` (
  `Nr` varchar(4) NOT NULL,
  `Klartext` varchar(30) DEFAULT NULL,
  `StatistikKrz` char(1) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  PRIMARY KEY (`Nr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchildFilter`
--

DROP TABLE IF EXISTS `SchildFilter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchildFilter` (
  `ID` int(11) NOT NULL,
  `Art` char(1) DEFAULT NULL,
  `Name` varchar(50) NOT NULL,
  `Beschreibung` varchar(255) DEFAULT NULL,
  `Tabellen` varchar(255) DEFAULT NULL,
  `ZusatzTabellen` varchar(255) DEFAULT NULL,
  `Bedingung` text,
  `BedingungKlartext` text,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchildFilter_IDX1` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Schild_Verwaltung`
--

DROP TABLE IF EXISTS `Schild_Verwaltung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Schild_Verwaltung` (
  `BackupDatum` datetime DEFAULT NULL,
  `AutoBerechnung` datetime DEFAULT NULL,
  `DatumStatkue` datetime DEFAULT NULL,
  `DatumSchildIntern` datetime DEFAULT NULL,
  `Bescheinigung` varchar(255) DEFAULT NULL,
  `Stammblatt` varchar(255) DEFAULT NULL,
  `DatenGeprueft` char(1) DEFAULT '-',
  `FaecherUebernehmen` char(1) DEFAULT '+',
  `Version` varchar(10) DEFAULT NULL,
  `GU_ID` varchar(40) DEFAULT NULL,
  `StatistikJahr` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `LD_Datentyp` varchar(1) DEFAULT NULL,
  `DatumLoeschfristHinweisDeaktiviert` datetime DEFAULT NULL,
  `DatumLoeschfristHinweisDeaktiviertUserID` int(11) DEFAULT NULL,
  `DatumDatenGeloescht` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Schueler`
--

DROP TABLE IF EXISTS `Schueler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Schueler` (
  `ID` int(11) NOT NULL,
  `GU_ID` varchar(40) DEFAULT NULL,
  `SrcID` int(11) DEFAULT NULL,
  `IDext` varchar(30) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Vorname` varchar(30) DEFAULT NULL,
  `Zusatz` varchar(255) DEFAULT NULL,
  `Geburtsname` varchar(30) DEFAULT NULL,
  `Strasse` varchar(50) DEFAULT NULL,
  `PLZ` varchar(10) DEFAULT NULL,
  `OrtAbk` varchar(50) DEFAULT NULL,
  `Ortsteil_ID` int(11) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL,
  `EMail` varchar(100) DEFAULT NULL,
  `Fax` varchar(20) DEFAULT NULL,
  `AktSchuljahr` smallint(6) DEFAULT NULL,
  `AktAbschnitt` smallint(6) DEFAULT NULL,
  `Klasse` varchar(15) DEFAULT NULL,
  `Jahrgang` smallint(6) DEFAULT NULL,
  `PruefOrdnung` varchar(20) DEFAULT NULL,
  `Geburtsdatum` datetime DEFAULT NULL,
  `Geburtsort` varchar(100) DEFAULT NULL,
  `Volljaehrig` char(1) DEFAULT '-',
  `Geschlecht` smallint(6) DEFAULT NULL,
  `StaatKrz` varchar(4) DEFAULT NULL,
  `StaatKrz2` varchar(4) DEFAULT NULL,
  `StaatAbk` varchar(50) DEFAULT NULL,
  `Aussiedler` char(1) DEFAULT '-',
  `Religion_ID` int(11) DEFAULT NULL,
  `ReligionAbk` varchar(30) DEFAULT NULL,
  `Religionsabmeldung` datetime DEFAULT NULL,
  `Religionsanmeldung` datetime DEFAULT NULL,
  `Bafoeg` char(1) DEFAULT '-',
  `Schwerbehinderung` char(1) DEFAULT '-',
  `Foerderschwerpunkt_ID` int(11) DEFAULT NULL,
  `Sportbefreiung_ID` int(11) DEFAULT NULL,
  `Fahrschueler_ID` int(11) DEFAULT NULL,
  `Haltestelle_ID` int(11) DEFAULT NULL,
  `HaltestelleAbk` varchar(30) DEFAULT NULL,
  `ASDSchulform` varchar(4) DEFAULT NULL,
  `Jahrgang_ID` int(11) DEFAULT NULL,
  `ASDJahrgang` varchar(4) DEFAULT NULL,
  `Fachklasse_ID` int(11) DEFAULT NULL,
  `SchulpflichtErf` char(1) DEFAULT '-',
  `Anschreibdatum` datetime DEFAULT NULL,
  `Aufnahmedatum` datetime DEFAULT NULL,
  `Einschulungsjahr` smallint(6) DEFAULT NULL,
  `Einschulungsart_ID` int(11) DEFAULT NULL,
  `LSSchulNr` varchar(6) DEFAULT NULL,
  `LSSchulForm` varchar(4) DEFAULT NULL,
  `LSSchulformSIM` varchar(4) DEFAULT NULL,
  `LSJahrgang` varchar(4) DEFAULT NULL,
  `LSSchulentlassDatum` datetime DEFAULT NULL,
  `LSVersetzung` varchar(2) DEFAULT NULL,
  `LSSGL` varchar(5) DEFAULT NULL,
  `LSSGL_SIM` varchar(4) DEFAULT NULL,
  `LSFachklKennung` varchar(10) DEFAULT NULL,
  `LSFachklSIM` varchar(5) DEFAULT NULL,
  `LSEntlassgrund` varchar(50) DEFAULT NULL,
  `LSEntlassArt` varchar(4) DEFAULT NULL,
  `LSKlassenart` varchar(4) DEFAULT NULL,
  `LSRefPaed` char(1) DEFAULT NULL,
  `Entlassjahrgang` varchar(4) DEFAULT NULL,
  `Entlassjahrgang_ID` int(11) DEFAULT NULL,
  `Entlassdatum` datetime DEFAULT NULL,
  `Entlassgrund` varchar(50) DEFAULT NULL,
  `Entlassart` varchar(4) DEFAULT NULL,
  `SchulwechselNr` varchar(6) DEFAULT NULL,
  `Schulwechseldatum` datetime DEFAULT NULL,
  `Geloescht` char(1) DEFAULT '-',
  `Gesperrt` char(1) DEFAULT '-',
  `ModifiziertAm` datetime DEFAULT NULL,
  `ModifiziertVon` varchar(20) DEFAULT NULL,
  `Markiert` varchar(21) DEFAULT NULL,
  `FotoVorhanden` char(1) DEFAULT '-',
  `JVA` char(1) DEFAULT '-',
  `RefPaed` char(1) DEFAULT NULL,
  `KeineAuskunft` char(1) DEFAULT '-',
  `Lehrer` varchar(10) DEFAULT NULL,
  `Beruf` varchar(100) DEFAULT NULL,
  `AbschlussDatum` varchar(15) DEFAULT NULL,
  `Bemerkungen` text,
  `BeginnBildungsgang` datetime DEFAULT NULL,
  `Durchschnitt` varchar(4) DEFAULT NULL,
  `OrgFormKrz` char(1) DEFAULT NULL,
  `Klassenart` varchar(4) DEFAULT NULL,
  `DurchschnittsNote` varchar(4) DEFAULT NULL,
  `DSN_Text` varchar(15) DEFAULT NULL,
  `Berufsabschluss` char(1) DEFAULT '-',
  `KonfDruck` char(1) DEFAULT '-',
  `Schwerpunkt_ID` int(11) DEFAULT NULL,
  `BerufsschulpflErf` varchar(1) DEFAULT NULL,
  `StatusNSJ` int(11) DEFAULT NULL,
  `FachklasseNSJ_ID` int(11) DEFAULT NULL,
  `Buchkonto` float DEFAULT NULL,
  `VerkehrsspracheFamilie` varchar(2) DEFAULT NULL,
  `JahrZuzug` int(11) DEFAULT NULL,
  `DauerKindergartenbesuch` varchar(1) DEFAULT NULL,
  `VerpflichtungSprachfoerderkurs` varchar(1) DEFAULT NULL,
  `TeilnahmeSprachfoerderkurs` varchar(1) DEFAULT NULL,
  `Schulbuchgeldbefreit` varchar(1) DEFAULT NULL,
  `Autist` varchar(1) DEFAULT NULL,
  `GeburtslandSchueler` varchar(10) DEFAULT NULL,
  `GeburtslandVater` varchar(10) DEFAULT NULL,
  `GeburtslandMutter` varchar(10) DEFAULT NULL,
  `Uebergangsempfehlung_JG5` varchar(10) DEFAULT NULL,
  `ErsteSchulform_SI` varchar(10) DEFAULT NULL,
  `JahrWechsel_SI` int(11) DEFAULT NULL,
  `JahrWechsel_SII` int(11) DEFAULT NULL,
  `Migrationshintergrund` varchar(1) DEFAULT NULL,
  `Foerderschwerpunkt2_ID` int(11) DEFAULT NULL,
  `SortierungKlasse` int(11) DEFAULT NULL,
  `ExterneSchulnr` varchar(6) DEFAULT NULL,
  `Kindergarten_ID` int(11) DEFAULT NULL,
  `LetzterBerufsAbschluss` varchar(10) DEFAULT NULL,
  `LetzterAllgAbschluss` varchar(10) DEFAULT NULL,
  `Land` varchar(2) DEFAULT NULL,
  `AV_Leist` int(11) DEFAULT NULL,
  `AV_Zuv` int(11) DEFAULT NULL,
  `AV_Selbst` int(11) DEFAULT NULL,
  `SV_Verant` int(11) DEFAULT NULL,
  `SV_Konfl` int(11) DEFAULT NULL,
  `SV_Koop` int(11) DEFAULT NULL,
  `Duplikat` varchar(1) DEFAULT '-',
  `EinschulungsartASD` varchar(2) DEFAULT NULL,
  `Hausnr` varchar(10) DEFAULT NULL,
  `Strassenname` varchar(50) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `BilingualerZweig` varchar(1) DEFAULT NULL,
  `DurchschnittsnoteFHR` varchar(4) DEFAULT NULL,
  `DSN_FHR_Text` varchar(15) DEFAULT NULL,
  `Eigenanteil` float DEFAULT NULL,
  `StaatAbk2` varchar(50) DEFAULT NULL,
  `ZustimmungFoto` varchar(1) DEFAULT '-',
  `BKAZVO` int(11) DEFAULT NULL,
  `HatBerufsausbildung` varchar(1) DEFAULT '-',
  `Ausweisnummer` varchar(30) DEFAULT NULL,
  `AOSF` char(1) DEFAULT NULL,
  `EPJahre` int(11) DEFAULT '2',
  `LSBemerkung` varchar(255) DEFAULT NULL,
  `WechselBestaetigt` varchar(1) DEFAULT '-',
  `DauerBildungsgang` int(11) DEFAULT NULL,
  `AnmeldeDatum` datetime DEFAULT NULL,
  `MeisterBafoeg` varchar(1) DEFAULT '-',
  `OnlineAnmeldung` varchar(1) DEFAULT '-',
  `Dokumentenverzeichnis` varchar(255) DEFAULT NULL,
  `Berufsqualifikation` varchar(100) DEFAULT NULL,
  `HausnrZusatz` varchar(30) DEFAULT NULL,
  `ZieldifferentesLernen` varchar(1) DEFAULT '-',
  `ZusatzNachname` varchar(30) DEFAULT NULL,
  `EndeEingliederung` datetime DEFAULT NULL,
  `SchulEmail` varchar(100) DEFAULT NULL,
  `EndeAnschlussfoerderung` datetime DEFAULT NULL,
  `MasernImpfnachweis` varchar(1) DEFAULT NULL,
  `Lernstandsbericht` varchar(1) DEFAULT '-',
  `SprachfoerderungVon` datetime DEFAULT NULL,
  `SprachfoerderungBis` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Schueler_IDX1` (`GU_ID`),
  KEY `PLZ_IX` (`PLZ`),
  KEY `Ortsteil_IX` (`Ortsteil_ID`),
  KEY `Klasse_IX` (`Klasse`),
  KEY `Staat_IX` (`StaatKrz`),
  KEY `Religion_IX` (`Religion_ID`),
  KEY `Foerderschwerpunkt_IX` (`Foerderschwerpunkt_ID`),
  KEY `Sportbefreiung_IX` (`Sportbefreiung_ID`),
  KEY `Fahrschueler_IX` (`Fahrschueler_ID`),
  KEY `Haltestelle_IX` (`Haltestelle_ID`),
  KEY `Einschulungsart_IX` (`Einschulungsart_ID`),
  CONSTRAINT `Schueler_ibfk_1` FOREIGN KEY (`PLZ`) REFERENCES `K_Ort` (`PLZ`),
  CONSTRAINT `Schueler_ibfk_10` FOREIGN KEY (`Einschulungsart_ID`) REFERENCES `K_Einschulungsart` (`ID`),
  CONSTRAINT `Schueler_ibfk_2` FOREIGN KEY (`Ortsteil_ID`) REFERENCES `K_Ortsteil` (`ID`),
  CONSTRAINT `Schueler_ibfk_3` FOREIGN KEY (`Klasse`) REFERENCES `Versetzung` (`Klasse`),
  CONSTRAINT `Schueler_ibfk_4` FOREIGN KEY (`StaatKrz`) REFERENCES `K_Staat` (`StatistikKrz`),
  CONSTRAINT `Schueler_ibfk_5` FOREIGN KEY (`Religion_ID`) REFERENCES `K_Religion` (`ID`),
  CONSTRAINT `Schueler_ibfk_6` FOREIGN KEY (`Foerderschwerpunkt_ID`) REFERENCES `K_Foerderschwerpunkt` (`ID`),
  CONSTRAINT `Schueler_ibfk_7` FOREIGN KEY (`Sportbefreiung_ID`) REFERENCES `K_Sportbefreiung` (`ID`),
  CONSTRAINT `Schueler_ibfk_8` FOREIGN KEY (`Fahrschueler_ID`) REFERENCES `K_Fahrschuelerart` (`ID`),
  CONSTRAINT `Schueler_ibfk_9` FOREIGN KEY (`Haltestelle_ID`) REFERENCES `K_Haltestelle` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerAbgaenge`
--

DROP TABLE IF EXISTS `SchuelerAbgaenge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerAbgaenge` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `BemerkungIntern` varchar(30) DEFAULT NULL,
  `AbgangsSchulform` varchar(4) DEFAULT NULL,
  `AbgangsBeschreibung` varchar(200) DEFAULT NULL,
  `OrganisationsformKrz` char(1) DEFAULT NULL,
  `AbgangsSchule` varchar(100) DEFAULT NULL,
  `AbgangsSchuleAnschr` varchar(100) DEFAULT NULL,
  `AbgangsSchulNr` varchar(6) DEFAULT NULL,
  `LSJahrgang` varchar(4) DEFAULT NULL,
  `LSEntlassArt` varchar(4) DEFAULT NULL,
  `LSSchulformSIM` varchar(4) DEFAULT NULL,
  `LSSchulEntlassDatum` datetime DEFAULT NULL,
  `LSVersetzung` varchar(2) DEFAULT NULL,
  `LSSGL` varchar(5) DEFAULT NULL,
  `LSFachklKennung` varchar(10) DEFAULT NULL,
  `LSFachklSIM` varchar(5) DEFAULT NULL,
  `FuerSIMExport` char(1) DEFAULT '-',
  `LSBeginnDatum` datetime DEFAULT NULL,
  `LSBeginnJahrgang` varchar(2) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  CONSTRAINT `SchuelerAbgaenge_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerAbiFaecher`
--

DROP TABLE IF EXISTS `SchuelerAbiFaecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerAbiFaecher` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `FachKrz` varchar(20) DEFAULT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `AbiFach` char(1) DEFAULT NULL,
  `Gekoppelt` char(1) DEFAULT NULL,
  `P12_1` varchar(4) DEFAULT NULL,
  `H12_1` int(11) DEFAULT NULL,
  `R12_1` char(1) DEFAULT '-',
  `S12_1` char(1) DEFAULT '-',
  `W12_1` smallint(6) DEFAULT NULL,
  `P12_2` varchar(4) DEFAULT NULL,
  `H12_2` int(11) DEFAULT NULL,
  `R12_2` char(1) DEFAULT '-',
  `S12_2` char(1) DEFAULT '-',
  `W12_2` smallint(6) DEFAULT NULL,
  `P13_1` varchar(4) DEFAULT NULL,
  `H13_1` int(11) DEFAULT NULL,
  `R13_1` char(1) DEFAULT '-',
  `S13_1` char(1) DEFAULT '-',
  `W13_1` smallint(6) DEFAULT NULL,
  `P13_2` varchar(4) DEFAULT NULL,
  `H13_2` int(11) DEFAULT NULL,
  `R13_2` char(1) DEFAULT '-',
  `S13_2` char(1) DEFAULT '-',
  `W13_2` smallint(6) DEFAULT NULL,
  `Zulassung` smallint(6) DEFAULT NULL,
  `Durchschnitt` float DEFAULT NULL,
  `AbiPruefErgebnis` smallint(6) DEFAULT NULL,
  `Zwischenstand` smallint(6) DEFAULT NULL,
  `MdlPflichtPruefung` char(1) DEFAULT '-',
  `MdlFreiwPruefung` char(1) DEFAULT '-',
  `MdlBestPruefung` char(1) DEFAULT '-',
  `MdlPruefErgebnis` smallint(6) DEFAULT NULL,
  `MdlPruefFolge` smallint(6) DEFAULT NULL,
  `AbiErgebnis` smallint(6) DEFAULT NULL,
  `P_FA` varchar(2) DEFAULT NULL,
  `Kurs_ID` int(11) DEFAULT NULL,
  `FSortierung` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Fachlehrer` varchar(10) DEFAULT NULL,
  `P11_1` varchar(2) DEFAULT NULL,
  `P11_2` varchar(2) DEFAULT NULL,
  `S11_1` varchar(1) DEFAULT NULL,
  `S11_2` varchar(1) DEFAULT NULL,
  `R_FA` varchar(1) DEFAULT '-',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerAbiFaecher_IDX1` (`Schueler_ID`,`Fach_ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `SchuelerAbiFaecher_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerAbiFaecher_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerAbitur`
--

DROP TABLE IF EXISTS `SchuelerAbitur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerAbitur` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Jahr` int(11) DEFAULT NULL,
  `Abschnitt` int(11) DEFAULT NULL,
  `Zugelassen` char(1) DEFAULT '-',
  `SummeGK` smallint(6) DEFAULT NULL,
  `SummeLK` smallint(6) DEFAULT NULL,
  `SummenOK` smallint(6) DEFAULT NULL,
  `PruefungBestanden` char(1) DEFAULT '-',
  `Note` varchar(4) DEFAULT NULL,
  `GesamtPunktzahl` smallint(6) DEFAULT NULL,
  `Notensprung` smallint(6) DEFAULT NULL,
  `FehlendePunktzahl` smallint(6) DEFAULT NULL,
  `AnzRelLK` smallint(6) DEFAULT NULL,
  `AnzRelGK` smallint(6) DEFAULT NULL,
  `AnzRelOK` smallint(6) DEFAULT NULL,
  `AnzDefLK` smallint(6) DEFAULT NULL,
  `AnzDefGK` smallint(6) DEFAULT NULL,
  `BesondereLernleistung` char(1) DEFAULT '-',
  `Latinum` char(1) DEFAULT '-',
  `KlLatinum` char(1) DEFAULT '-',
  `Graecum` char(1) DEFAULT '-',
  `Hebraicum` char(1) DEFAULT '-',
  `FranzBilingual` char(1) DEFAULT '-',
  `FehlStd` int(11) DEFAULT NULL,
  `uFehlStd` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `BLL_Art` varchar(1) DEFAULT 'K',
  `BLL_Punkte` int(11) DEFAULT NULL,
  `FS2_SekI_manuell` varchar(1) DEFAULT '-',
  `Punktsumme_II` int(11) DEFAULT NULL,
  `Defizite_II` int(11) DEFAULT NULL,
  `LK_Defizite_II` int(11) DEFAULT NULL,
  `Thema_BLL` varchar(255) DEFAULT NULL,
  `Thema_PJK` varchar(255) DEFAULT NULL,
  `Punktsumme_I` int(11) DEFAULT NULL,
  `Defizite_I` int(11) DEFAULT NULL,
  `LK_Defizite_I` int(11) DEFAULT NULL,
  `Kurse_I` int(11) DEFAULT NULL,
  `FA_Punkte` int(11) DEFAULT NULL,
  `FA_Fach` varchar(130) DEFAULT NULL,
  `AnzahlKurse_0` int(11) DEFAULT NULL,
  `Durchschnitt_I` float DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerAbitur_IDX1` (`Schueler_ID`),
  CONSTRAINT `SchuelerAbitur_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerAnkreuzfloskeln`
--

DROP TABLE IF EXISTS `SchuelerAnkreuzfloskeln`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerAnkreuzfloskeln` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL,
  `Abschnitt` int(11) NOT NULL,
  `Floskel_ID` int(11) NOT NULL,
  `Stufe1` varchar(1) DEFAULT NULL,
  `Stufe2` varchar(1) DEFAULT NULL,
  `Stufe3` varchar(1) DEFAULT NULL,
  `Stufe4` varchar(1) DEFAULT NULL,
  `Stufe5` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SchuelerAnkreuzfloskeln_IDX1` (`Schueler_ID`,`Jahr`,`Abschnitt`,`Floskel_ID`),
  KEY `SchuelerAKF_Floskel_FK` (`Floskel_ID`),
  CONSTRAINT `SchuelerAKF_Floskel_FK` FOREIGN KEY (`Floskel_ID`) REFERENCES `K_Ankreuzfloskeln` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerAKF_Schueler_FK` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerBKAbschluss`
--

DROP TABLE IF EXISTS `SchuelerBKAbschluss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerBKAbschluss` (
  `Schueler_ID` int(11) NOT NULL,
  `Zulassung` char(1) DEFAULT NULL,
  `Bestanden` char(1) DEFAULT NULL,
  `Zeugnis` char(1) DEFAULT NULL,
  `ZertifikatBK` char(1) DEFAULT NULL,
  `ZulassungErwBK` char(1) DEFAULT NULL,
  `BestandenErwBK` char(1) DEFAULT NULL,
  `ZulassungBA` char(1) DEFAULT NULL,
  `BestandenBA` char(1) DEFAULT NULL,
  `PraktPrfNote` varchar(4) DEFAULT NULL,
  `NoteKolloquium` varchar(4) DEFAULT NULL,
  `ThemaAbschlussarbeit` text,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `BAP_Vorhanden` varchar(1) DEFAULT NULL,
  `NoteFachpraxis` varchar(2) DEFAULT NULL,
  `FachPraktAnteilAusr` varchar(1) DEFAULT NULL,
  `Jahr` int(11) DEFAULT NULL,
  `Abschnitt` int(11) DEFAULT NULL,
  PRIMARY KEY (`Schueler_ID`),
  CONSTRAINT `SchuelerBKAbschluss_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerBKFaecher`
--

DROP TABLE IF EXISTS `SchuelerBKFaecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerBKFaecher` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `FachKrz` varchar(20) DEFAULT NULL,
  `FachSchriftlich` char(1) DEFAULT '-',
  `FachSchriftlichBA` char(1) DEFAULT '-',
  `Vornote` varchar(4) DEFAULT NULL,
  `NoteSchriftlich` varchar(4) DEFAULT NULL,
  `MdlPruefung` char(1) DEFAULT NULL,
  `MdlPruefungFW` char(1) DEFAULT NULL,
  `NoteMuendlich` varchar(4) DEFAULT NULL,
  `NotePrfGesamt` varchar(4) DEFAULT NULL,
  `NoteAbschluss` varchar(4) DEFAULT NULL,
  `FSortierung` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Fachlehrer` varchar(10) DEFAULT NULL,
  `NoteAbschlussBA` varchar(2) DEFAULT NULL,
  `Kursart` varchar(5) DEFAULT NULL,
  `Jahr` int(11) DEFAULT NULL,
  `Abschnitt` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `SchuelerBKFaecher_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerBKFaecher_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerDatenschutz`
--

DROP TABLE IF EXISTS `SchuelerDatenschutz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerDatenschutz` (
  `Schueler_ID` int(11) NOT NULL,
  `Datenschutz_ID` int(11) NOT NULL,
  `Status` varchar(1) DEFAULT '-',
  `SchulnrEigner` int(11) NOT NULL,
  PRIMARY KEY (`Schueler_ID`,`Datenschutz_ID`),
  KEY `SchuelerDatenschutz_FK` (`Datenschutz_ID`),
  CONSTRAINT `SchuelerDatenschutz_FK2` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `SchuelerDatenschutz_FK` FOREIGN KEY (`Datenschutz_ID`) REFERENCES `K_Datenschutz` (`ID`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerEinzelleistungen`
--

DROP TABLE IF EXISTS `SchuelerEinzelleistungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerEinzelleistungen` (
  `SchulnrEigner` int(11) NOT NULL,
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Datum` datetime DEFAULT NULL,
  `Lehrer_ID` int(11) DEFAULT NULL,
  `Art_ID` int(11) DEFAULT NULL,
  `Bemerkung` varchar(100) DEFAULT NULL,
  `Leistung_ID` bigint(20) DEFAULT NULL,
  `NotenKrz` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SchuelerEL_Art_FK` (`Art_ID`),
  CONSTRAINT `SchuelerEL_Art_FK` FOREIGN KEY (`Art_ID`) REFERENCES `K_Einzelleistungen` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerErzAdr`
--

DROP TABLE IF EXISTS `SchuelerErzAdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerErzAdr` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Erzieherart_ID` int(11) DEFAULT NULL,
  `Anrede1` varchar(20) DEFAULT NULL,
  `Titel1` varchar(10) DEFAULT NULL,
  `Name1` varchar(50) DEFAULT NULL,
  `Vorname1` varchar(30) DEFAULT NULL,
  `Anrede2` varchar(20) DEFAULT NULL,
  `Titel2` varchar(10) DEFAULT NULL,
  `Name2` varchar(50) DEFAULT NULL,
  `Vorname2` varchar(30) DEFAULT NULL,
  `ErzStrasse` varchar(50) DEFAULT NULL,
  `ErzPLZ` varchar(10) DEFAULT NULL,
  `ErzOrtsteil_ID` int(11) DEFAULT NULL,
  `ErzAnschreiben` char(1) DEFAULT '+',
  `ErzBemerkung` varchar(255) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT NULL,
  `ErzEMail` varchar(100) DEFAULT NULL,
  `ErzAdrZusatz` varchar(50) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Erz1StaatKrz` varchar(3) DEFAULT NULL,
  `Erz2StaatKrz` varchar(3) DEFAULT NULL,
  `ErzEMail2` varchar(100) DEFAULT NULL,
  `Erz1ZusatzNachname` varchar(30) DEFAULT NULL,
  `Erz2ZusatzNachname` varchar(30) DEFAULT NULL,
  `Bemerkungen` text,
  PRIMARY KEY (`ID`),
  KEY `SchuelerErzAdr_IDX1` (`Schueler_ID`),
  KEY `ErzPLZ_IX` (`ErzPLZ`),
  KEY `ErzOrtsteil_IX` (`ErzOrtsteil_ID`),
  KEY `Erzieherart_IX` (`Erzieherart_ID`),
  CONSTRAINT `SchuelerErzAdr_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerErzAdr_ibfk_2` FOREIGN KEY (`ErzPLZ`) REFERENCES `K_Ort` (`PLZ`),
  CONSTRAINT `SchuelerErzAdr_ibfk_3` FOREIGN KEY (`ErzOrtsteil_ID`) REFERENCES `K_Ortsteil` (`ID`),
  CONSTRAINT `SchuelerErzAdr_ibfk_4` FOREIGN KEY (`Erzieherart_ID`) REFERENCES `K_Erzieherart` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerErzFunktion`
--

DROP TABLE IF EXISTS `SchuelerErzFunktion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerErzFunktion` (
  `ID` int(11) NOT NULL,
  `Erzieher_ID` int(11) NOT NULL,
  `Funktion_ID` int(11) NOT NULL,
  `Person` smallint(6) DEFAULT NULL,
  `Klasse` varchar(15) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Erzieher_IX` (`Erzieher_ID`),
  KEY `Funktion_IX` (`Funktion_ID`),
  CONSTRAINT `SchuelerErzFunktion_ibfk_1` FOREIGN KEY (`Erzieher_ID`) REFERENCES `SchuelerErzAdr` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerErzFunktion_ibfk_2` FOREIGN KEY (`Funktion_ID`) REFERENCES `K_Erzieherfunktion` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerFHR`
--

DROP TABLE IF EXISTS `SchuelerFHR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerFHR` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `FHRErreicht` char(1) DEFAULT '-',
  `Note` varchar(4) DEFAULT NULL,
  `GesamtPunktzahl` smallint(6) DEFAULT NULL,
  `SummeGK` smallint(6) DEFAULT NULL,
  `SummeLK` smallint(6) DEFAULT NULL,
  `SummenOK` smallint(6) DEFAULT NULL,
  `AnzRelLK` smallint(6) DEFAULT NULL,
  `AnzRelGK` smallint(6) DEFAULT NULL,
  `AnzRelOK` smallint(6) DEFAULT NULL,
  `AnzDefLK` smallint(6) DEFAULT NULL,
  `AnzDefGK` smallint(6) DEFAULT NULL,
  `AnzDefOK` smallint(6) DEFAULT NULL,
  `JSII_2_1` smallint(6) DEFAULT NULL,
  `JSII_2_1_W` smallint(6) DEFAULT NULL,
  `JSII_2_2` smallint(6) DEFAULT NULL,
  `JSII_2_2_W` smallint(6) DEFAULT NULL,
  `JSII_3_1` smallint(6) DEFAULT NULL,
  `JSII_3_1_W` smallint(6) DEFAULT NULL,
  `JSII_3_2` smallint(6) DEFAULT NULL,
  `JSII_3_2_W` smallint(6) DEFAULT NULL,
  `ASII_2_1` smallint(6) DEFAULT NULL,
  `ASII_2_2` smallint(6) DEFAULT NULL,
  `ASII_2_1_W` smallint(6) DEFAULT NULL,
  `ASII_2_2_W` smallint(6) DEFAULT NULL,
  `ASII_3_1` smallint(6) DEFAULT NULL,
  `ASII_3_2` smallint(6) DEFAULT NULL,
  `ASII_3_1_W` smallint(6) DEFAULT NULL,
  `ASII_3_2_W` smallint(6) DEFAULT NULL,
  `WSII_2_1` varchar(1) DEFAULT NULL,
  `WSII_2_2` varchar(1) DEFAULT NULL,
  `WSII_2_1_W` varchar(1) DEFAULT NULL,
  `WSII_2_2_W` varchar(1) DEFAULT NULL,
  `WSII_3_1` varchar(1) DEFAULT NULL,
  `WSII_3_2` varchar(1) DEFAULT NULL,
  `WSII_3_1_W` varchar(1) DEFAULT NULL,
  `WSII_3_2_W` varchar(1) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerFHR_IDX1` (`Schueler_ID`),
  CONSTRAINT `SchuelerFHR_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerFHRFaecher`
--

DROP TABLE IF EXISTS `SchuelerFHRFaecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerFHRFaecher` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `FachKrz` varchar(20) DEFAULT NULL,
  `PSII_2_1` varchar(4) DEFAULT NULL,
  `HSII_2_1` int(11) DEFAULT NULL,
  `RSII_2_1` char(1) DEFAULT '-',
  `PSII_2_2` varchar(4) DEFAULT NULL,
  `HSII_2_2` int(11) DEFAULT NULL,
  `RSII_2_2` char(1) DEFAULT '-',
  `PSII_2_1_W` varchar(4) DEFAULT NULL,
  `HSII_2_1_W` int(11) DEFAULT NULL,
  `RSII_2_1_W` char(1) DEFAULT '-',
  `PSII_2_2_W` varchar(4) DEFAULT NULL,
  `HSII_2_2_W` int(11) DEFAULT NULL,
  `RSII_2_2_W` char(1) DEFAULT '-',
  `PSII_3_1` varchar(4) DEFAULT NULL,
  `HSII_3_1` int(11) DEFAULT NULL,
  `RSII_3_1` char(1) DEFAULT '-',
  `PSII_3_2` varchar(4) DEFAULT NULL,
  `HSII_3_2` int(11) DEFAULT NULL,
  `RSII_3_2` char(1) DEFAULT '-',
  `PSII_3_1_W` varchar(4) DEFAULT NULL,
  `HSII_3_1_W` int(11) DEFAULT NULL,
  `RSII_3_1_W` char(1) DEFAULT '-',
  `PSII_3_2_W` varchar(4) DEFAULT NULL,
  `HSII_3_2_W` int(11) DEFAULT NULL,
  `RSII_3_2_W` char(1) DEFAULT '-',
  `KSII_2_1` varchar(5) DEFAULT NULL,
  `KSII_2_2` varchar(5) DEFAULT NULL,
  `KSII_2_1_W` varchar(5) DEFAULT NULL,
  `KSII_2_2_W` varchar(5) DEFAULT NULL,
  `KSII_3_1` varchar(5) DEFAULT NULL,
  `KSII_3_2` varchar(5) DEFAULT NULL,
  `KSII_3_1_W` varchar(5) DEFAULT NULL,
  `KSII_3_2_W` varchar(5) DEFAULT NULL,
  `FSortierung` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerFHRFaecher_IDX1` (`Schueler_ID`,`Fach_ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `SchuelerFHRFaecher_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerFHRFaecher_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerFehlstunden`
--

DROP TABLE IF EXISTS `SchuelerFehlstunden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerFehlstunden` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `SchulnrEigner` int(11) NOT NULL,
  `Abschnitt_ID` int(11) NOT NULL,
  `Datum` datetime NOT NULL,
  `Fach_ID` int(11) DEFAULT NULL,
  `Fehlstd` float NOT NULL,
  `VonStd` int(11) DEFAULT NULL,
  `BisStd` int(11) DEFAULT NULL,
  `Entschuldigt` varchar(1) DEFAULT NULL,
  `Lehrer_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SchuelerFehlstunden_Abschnitt_FK` (`Abschnitt_ID`),
  CONSTRAINT `SchuelerFehlstunden_Abschnitt_FK` FOREIGN KEY (`Abschnitt_ID`) REFERENCES `SchuelerLernabschnittsdaten` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerFoerderempfehlungen`
--

DROP TABLE IF EXISTS `SchuelerFoerderempfehlungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerFoerderempfehlungen` (
  `GU_ID` varchar(40) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `DatumAngelegt` datetime NOT NULL,
  `Klasse` varchar(15) DEFAULT NULL,
  `Jahr` int(11) DEFAULT NULL,
  `Abschnitt` int(11) DEFAULT NULL,
  `Fach_ID` int(11) DEFAULT NULL,
  `Lehrer_ID` int(11) DEFAULT NULL,
  `DatumAenderungSchild` datetime DEFAULT NULL,
  `DatumAenderungSchildWeb` datetime DEFAULT NULL,
  `Kurs` varchar(20) DEFAULT NULL,
  `Inhaltl_Prozessbez_Komp` text,
  `Methodische_Komp` text,
  `Lern_Arbeitsverhalten` text,
  `Massn_Inhaltl_Prozessbez_Komp` text,
  `Massn_Methodische_Komp` text,
  `Massn_Lern_Arbeitsverhalten` text,
  `Verantwortlichkeit_Eltern` text,
  `Verantwortlichkeit_Schueler` text,
  `Zeitrahmen_von_Datum` datetime DEFAULT NULL,
  `Zeitrahmen_bis_Datum` datetime DEFAULT NULL,
  `Ueberpruefung_Datum` datetime DEFAULT NULL,
  `Naechstes_Beratungsgespraech` datetime DEFAULT NULL,
  `Leistung_ID` int(11) DEFAULT NULL,
  `Kurs_ID` int(11) DEFAULT NULL,
  `EingabeFertig` varchar(1) DEFAULT '-',
  `Faecher` varchar(255) DEFAULT NULL,
  `Abgeschlossen` varchar(1) DEFAULT '-',
  PRIMARY KEY (`GU_ID`),
  KEY `SchuelerFE_Schueler_FK` (`Schueler_ID`),
  CONSTRAINT `SchuelerFE_Schueler_FK` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerFotos`
--

DROP TABLE IF EXISTS `SchuelerFotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerFotos` (
  `Schueler_ID` int(11) NOT NULL,
  `Foto` mediumblob,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Schueler_ID`),
  CONSTRAINT `SchuelerFotos_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerGSDaten`
--

DROP TABLE IF EXISTS `SchuelerGSDaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerGSDaten` (
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Note_Sprachgebrauch` int(11) DEFAULT NULL,
  `Note_Lesen` int(11) DEFAULT NULL,
  `Note_Rechtschreiben` int(11) DEFAULT NULL,
  `Note_Sachunterricht` int(11) DEFAULT NULL,
  `Note_Mathematik` int(11) DEFAULT NULL,
  `Note_Englisch` int(11) DEFAULT NULL,
  `Note_KunstTextil` int(11) DEFAULT NULL,
  `Note_Musik` int(11) DEFAULT NULL,
  `Note_Sport` int(11) DEFAULT NULL,
  `Note_Religion` int(11) DEFAULT NULL,
  `Durchschnittsnote_Sprache` float DEFAULT NULL,
  `Durchschnittsnote_Einfach` float DEFAULT NULL,
  `Durchschnittsnote_Gewichtet` float DEFAULT NULL,
  `Anrede_Klassenlehrer` varchar(10) DEFAULT NULL,
  `Nachname_Klassenlehrer` varchar(50) DEFAULT NULL,
  `GS_Klasse` varchar(10) DEFAULT NULL,
  `Bemerkungen` text,
  `Geschwisterkind` varchar(1) DEFAULT '-',
  PRIMARY KEY (`Schueler_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerKAoADaten`
--

DROP TABLE IF EXISTS `SchuelerKAoADaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerKAoADaten` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Jahr` int(11) NOT NULL,
  `Abschnitt` int(11) NOT NULL,
  `Jahrgang` varchar(2) DEFAULT NULL,
  `Kategorie` varchar(10) DEFAULT NULL,
  `Merkmal` varchar(20) DEFAULT NULL,
  `Zusatzmerkmal` varchar(20) DEFAULT NULL,
  `Anschlussoption` varchar(10) DEFAULT NULL,
  `Berufsfeld` varchar(10) DEFAULT NULL,
  `Bemerkung` varchar(255) DEFAULT NULL,
  `KategorieID` int(11) DEFAULT NULL,
  `MerkmalID` int(11) DEFAULT NULL,
  `ZusatzmerkmalID` int(11) DEFAULT NULL,
  `AnschlussoptionID` int(11) DEFAULT NULL,
  `BerufsfeldID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SchuelerKAoADaten_Schueler_FK` (`Schueler_ID`),
  CONSTRAINT `SchuelerKAoADaten_Schueler_FK` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerLD_PSFachBem`
--

DROP TABLE IF EXISTS `SchuelerLD_PSFachBem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerLD_PSFachBem` (
  `ID` int(11) NOT NULL,
  `Abschnitt_ID` int(11) NOT NULL,
  `ASV` text,
  `LELS` text,
  `ESF` text,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `BemerkungFSP` text,
  `BemerkungVersetzung` text,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Abschnitt_IX` (`Abschnitt_ID`),
  KEY `SchuelerLD_PSFachBem_IDX1` (`Abschnitt_ID`),
  CONSTRAINT `SchuelerLD_PSFachBem_ibfk_1` FOREIGN KEY (`Abschnitt_ID`) REFERENCES `SchuelerLernabschnittsdaten` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerLeistungsdaten`
--

DROP TABLE IF EXISTS `SchuelerLeistungsdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerLeistungsdaten` (
  `ID` int(11) NOT NULL,
  `Abschnitt_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `Hochrechnung` int(11) DEFAULT '0',
  `FachLehrer` varchar(10) DEFAULT NULL,
  `Kursart` varchar(5) DEFAULT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `Kurs_ID` int(11) DEFAULT NULL,
  `NotenKrz` varchar(4) DEFAULT NULL,
  `Warnung` char(1) DEFAULT '-',
  `Warndatum` datetime DEFAULT NULL,
  `AbiFach` char(1) DEFAULT NULL,
  `Wochenstunden` smallint(6) DEFAULT NULL,
  `AbiZeugnis` char(1) DEFAULT '-',
  `Prognose` char(1) DEFAULT NULL,
  `Fehlstd` smallint(6) DEFAULT NULL,
  `uFehlstd` smallint(6) DEFAULT NULL,
  `Sortierung` smallint(6) DEFAULT '32000',
  `Lernentw` text,
  `Gekoppelt` char(1) DEFAULT '-',
  `VorherAbgeschl` char(1) DEFAULT '-',
  `AbschlussJahrgang` varchar(4) DEFAULT NULL,
  `HochrechnungStatus` varchar(1) DEFAULT NULL,
  `SchulNr` int(11) DEFAULT NULL,
  `Zusatzkraft` varchar(10) DEFAULT NULL,
  `WochenstdZusatzkraft` int(11) DEFAULT NULL,
  `Prf10Fach` varchar(1) DEFAULT NULL,
  `AufZeugnis` varchar(1) DEFAULT '+',
  `Gewichtung` int(11) DEFAULT '1',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `NoteAbschlussBA` varchar(2) DEFAULT NULL,
  `Umfang` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerLeistungsdaten_IDX2` (`Abschnitt_ID`,`Fach_ID`,`Kursart`,`Kurs_ID`),
  KEY `Abschnitt_IX` (`Abschnitt_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  KEY `Kurs_IX` (`Kurs_ID`),
  KEY `SchuelerLeistungsdaten_Kurs_IDX` (`Kurs_ID`),
  CONSTRAINT `SchuelerLeistungsdaten_ibfk_1` FOREIGN KEY (`Abschnitt_ID`) REFERENCES `SchuelerLernabschnittsdaten` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerLeistungsdaten_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`),
  CONSTRAINT `SchuelerLeistungsdaten_ibfk_3` FOREIGN KEY (`Kurs_ID`) REFERENCES `Kurse` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerLernabschnittsdaten`
--

DROP TABLE IF EXISTS `SchuelerLernabschnittsdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerLernabschnittsdaten` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Jahr` smallint(6) NOT NULL,
  `Abschnitt` smallint(6) NOT NULL,
  `Bildungsgang` char(1) NOT NULL,
  `WechselNr` smallint(6) NOT NULL,
  `Jahrgang` smallint(6) DEFAULT NULL,
  `Hochrechnung` int(11) DEFAULT NULL,
  `SemesterWertung` char(1) DEFAULT '+',
  `PruefOrdnung` varchar(20) DEFAULT NULL,
  `Klasse` varchar(15) DEFAULT NULL,
  `Folgeklasse` varchar(15) DEFAULT NULL,
  `Verspaetet` smallint(6) DEFAULT NULL,
  `NPV_Fach_ID` int(11) DEFAULT NULL,
  `NPV_NoteKrz` varchar(4) DEFAULT NULL,
  `NPV_Datum` datetime DEFAULT NULL,
  `NPAA_Fach_ID` int(11) DEFAULT NULL,
  `NPAA_NoteKrz` varchar(4) DEFAULT NULL,
  `NPAA_Datum` datetime DEFAULT NULL,
  `NPBQ_Fach_ID` int(11) DEFAULT NULL,
  `NPBQ_NoteKrz` varchar(4) DEFAULT NULL,
  `NPBQ_Datum` datetime DEFAULT NULL,
  `VersetzungKrz` varchar(4) DEFAULT NULL,
  `AbschlussArt` smallint(6) DEFAULT NULL,
  `Abschluss` varchar(50) DEFAULT NULL,
  `Abschluss_B` varchar(50) DEFAULT NULL,
  `AbschlIstPrognose` char(1) DEFAULT '-',
  `Konferenzdatum` datetime DEFAULT NULL,
  `ZeugnisDatum` datetime DEFAULT NULL,
  `KlassenLehrer` varchar(10) DEFAULT NULL,
  `ASDSchulgliederung` varchar(4) DEFAULT NULL,
  `ASDJahrgang` varchar(4) DEFAULT NULL,
  `Jahrgang_ID` int(11) DEFAULT NULL,
  `Fachklasse_ID` int(11) DEFAULT NULL,
  `Schwerpunkt_ID` int(11) DEFAULT NULL,
  `ZeugnisBem` text,
  `Schwerbehinderung` char(1) DEFAULT '-',
  `Foerderschwerpunkt_ID` int(11) DEFAULT NULL,
  `OrgFormKrz` char(1) DEFAULT NULL,
  `RefPaed` char(1) DEFAULT '-',
  `Klassenart` varchar(4) DEFAULT NULL,
  `SumFehlStd` smallint(6) DEFAULT NULL,
  `SumFehlStdU` smallint(6) DEFAULT NULL,
  `Wiederholung` char(1) DEFAULT NULL,
  `Gesamtnote_GS` smallint(6) DEFAULT NULL,
  `Gesamtnote_NW` smallint(6) DEFAULT NULL,
  `Foerderschwerpunkt2_ID` int(11) DEFAULT NULL,
  `DSNote` varchar(4) DEFAULT NULL,
  `AV_Leist` int(11) DEFAULT NULL,
  `AV_Zuv` int(11) DEFAULT NULL,
  `AV_Selbst` int(11) DEFAULT NULL,
  `SV_Verant` int(11) DEFAULT NULL,
  `SV_Konfl` int(11) DEFAULT NULL,
  `SV_Koop` int(11) DEFAULT NULL,
  `KN_Lehrer` varchar(10) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `StvKlassenlehrer_ID` int(11) DEFAULT NULL,
  `MoeglNPFaecher` text,
  `Zertifikate` varchar(30) DEFAULT NULL,
  `DatumFHR` datetime DEFAULT NULL,
  `PruefAlgoErgebnis` text,
  `Zeugnisart` varchar(5) DEFAULT NULL,
  `DatumVon` datetime DEFAULT NULL,
  `DatumBis` datetime DEFAULT NULL,
  `FehlstundenGrenzwert` int(11) DEFAULT NULL,
  `Sonderpaedagoge_ID` int(11) DEFAULT NULL,
  `FachPraktAnteilAusr` varchar(1) DEFAULT '-',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerLernabschnittsdaten_IDX1` (`Schueler_ID`,`Jahr`,`Abschnitt`,`Bildungsgang`,`WechselNr`),
  KEY `Schueler_IX` (`Schueler_ID`),
  KEY `Jahrgang_IX` (`Jahrgang_ID`),
  KEY `Fachklasse_IX` (`Fachklasse_ID`),
  KEY `Foerderschwerpunkt_IX` (`Foerderschwerpunkt_ID`),
  CONSTRAINT `SchuelerLernabschnittsdaten_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerLernabschnittsdaten_ibfk_2` FOREIGN KEY (`Jahrgang_ID`) REFERENCES `EigeneSchule_Jahrgaenge` (`ID`),
  CONSTRAINT `SchuelerLernabschnittsdaten_ibfk_3` FOREIGN KEY (`Fachklasse_ID`) REFERENCES `EigeneSchule_Fachklassen` (`ID`),
  CONSTRAINT `SchuelerLernabschnittsdaten_ibfk_4` FOREIGN KEY (`Foerderschwerpunkt_ID`) REFERENCES `K_Foerderschwerpunkt` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerListe`
--

DROP TABLE IF EXISTS `SchuelerListe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerListe` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Erzeuger` varchar(20) DEFAULT NULL,
  `Privat` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerListe_IDX1` (`Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerListe_Inhalt`
--

DROP TABLE IF EXISTS `SchuelerListe_Inhalt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerListe_Inhalt` (
  `Liste_ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Liste_ID`,`Schueler_ID`),
  KEY `Liste_IX` (`Liste_ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  CONSTRAINT `SchuelerListe_Inhalt_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerListe_Inhalt_ibfk_2` FOREIGN KEY (`Liste_ID`) REFERENCES `SchuelerListe` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerMerkmale`
--

DROP TABLE IF EXISTS `SchuelerMerkmale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerMerkmale` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Kurztext` varchar(10) NOT NULL DEFAULT '',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `DatumVon` datetime DEFAULT NULL,
  `DatumBis` datetime DEFAULT NULL,
  PRIMARY KEY (`Schueler_ID`,`Kurztext`),
  CONSTRAINT `SchuelerMerkmale_Schueler_FK` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerReportvorlagen`
--

DROP TABLE IF EXISTS `SchuelerReportvorlagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerReportvorlagen` (
  `User_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `ReportVorlage` varchar(255) DEFAULT NULL,
  `Schueler_IDs` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerSprachenfolge`
--

DROP TABLE IF EXISTS `SchuelerSprachenfolge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerSprachenfolge` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `JAHRGANGVON` smallint(6) DEFAULT NULL,
  `ABSCHNITTVON` smallint(6) DEFAULT NULL,
  `JAHRGANGBIS` smallint(6) DEFAULT NULL,
  `ABSCHNITTBIS` smallint(6) DEFAULT NULL,
  `Reihenfolge` char(1) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Referenzniveau` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `SchuelerSprachenfolge_IDX1` (`Schueler_ID`,`Fach_ID`),
  KEY `Schueler_IX` (`Schueler_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `SchuelerSprachenfolge_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerSprachenfolge_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerTelefone`
--

DROP TABLE IF EXISTS `SchuelerTelefone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerTelefone` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `TelefonArt_ID` int(11) NOT NULL,
  `Telefonnummer` varchar(20) DEFAULT NULL,
  `Bemerkung` varchar(50) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT '32000',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Gesperrt` varchar(1) DEFAULT '-',
  PRIMARY KEY (`ID`),
  KEY `SchuelerTelefone_IDX1` (`Schueler_ID`),
  KEY `Telefonart_IX` (`TelefonArt_ID`),
  CONSTRAINT `SchuelerTelefone_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerTelefone_ibfk_2` FOREIGN KEY (`TelefonArt_ID`) REFERENCES `K_Telefonart` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerVermerke`
--

DROP TABLE IF EXISTS `SchuelerVermerke`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerVermerke` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Vermerkart_ID` int(11) NOT NULL,
  `Datum` datetime DEFAULT NULL,
  `Bemerkung` text,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `AngelegtVon` varchar(20) DEFAULT NULL,
  `GeaendertVon` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SchuelerVermerke_IDX1` (`Schueler_ID`),
  KEY `Vermerkart_IX` (`Vermerkart_ID`),
  CONSTRAINT `SchuelerVermerke_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerVermerke_ibfk_2` FOREIGN KEY (`Vermerkart_ID`) REFERENCES `K_Vermerkart` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerWiedervorlage`
--

DROP TABLE IF EXISTS `SchuelerWiedervorlage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerWiedervorlage` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Bemerkung` varchar(255) DEFAULT NULL,
  `AngelegtAm` datetime DEFAULT NULL,
  `WiedervorlageAm` datetime DEFAULT NULL,
  `ErledigtAm` datetime DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Sekretariat` varchar(1) DEFAULT NULL,
  `Typ` varchar(1) DEFAULT NULL,
  `NichtLoeschen` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `SchuelerZuweisungen`
--

DROP TABLE IF EXISTS `SchuelerZuweisungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SchuelerZuweisungen` (
  `Abschnitt_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `Kursart` varchar(5) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`Abschnitt_ID`,`Fach_ID`),
  KEY `Abschnitt_IX` (`Abschnitt_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `SchuelerZuweisungen_ibfk_1` FOREIGN KEY (`Abschnitt_ID`) REFERENCES `SchuelerLernabschnittsdaten` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `SchuelerZuweisungen_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Schueler_AllgAdr`
--

DROP TABLE IF EXISTS `Schueler_AllgAdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Schueler_AllgAdr` (
  `ID` int(11) NOT NULL,
  `Schueler_ID` int(11) NOT NULL,
  `Adresse_ID` int(11) NOT NULL,
  `Vertragsart_ID` int(11) DEFAULT NULL,
  `Vertragsbeginn` datetime DEFAULT NULL,
  `Vertragsende` datetime DEFAULT NULL,
  `Ausbilder` varchar(30) DEFAULT NULL,
  `AllgAdrAnschreiben` char(1) DEFAULT '-',
  `Praktikum` char(1) DEFAULT '-',
  `Sortierung` int(11) DEFAULT NULL,
  `Ansprechpartner_ID` int(11) DEFAULT NULL,
  `Betreuungslehrer_ID` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Schueler_AllgAdr_IDX1` (`Schueler_ID`),
  KEY `Adresse_IX` (`Adresse_ID`),
  KEY `Vertragsart_IX` (`Vertragsart_ID`),
  CONSTRAINT `Schueler_AllgAdr_ibfk_1` FOREIGN KEY (`Schueler_ID`) REFERENCES `Schueler` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `Schueler_AllgAdr_ibfk_2` FOREIGN KEY (`Adresse_ID`) REFERENCES `K_AllgAdresse` (`ID`),
  CONSTRAINT `Schueler_AllgAdr_ibfk_3` FOREIGN KEY (`Vertragsart_ID`) REFERENCES `K_Beschaeftigungsart` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Stundentafel`
--

DROP TABLE IF EXISTS `Stundentafel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stundentafel` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(50) NOT NULL,
  `Jahrgang_ID` int(11) DEFAULT NULL,
  `ASDJahrgang` varchar(4) DEFAULT NULL,
  `Klasse` varchar(15) DEFAULT NULL,
  `SGL` varchar(4) DEFAULT NULL,
  `Fachklasse_ID` int(11) DEFAULT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `SchulnrEigner` int(11) DEFAULT NULL,
  `Sortierung` int(11) DEFAULT '32000',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Stundentafel_Faecher`
--

DROP TABLE IF EXISTS `Stundentafel_Faecher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Stundentafel_Faecher` (
  `ID` int(11) NOT NULL,
  `Stundentafel_ID` int(11) NOT NULL,
  `Fach_ID` int(11) NOT NULL,
  `KursartAllg` varchar(5) DEFAULT NULL,
  `WochenStd` smallint(6) DEFAULT NULL,
  `LehrerKrz` varchar(10) DEFAULT NULL,
  `EpochenUnterricht` char(1) DEFAULT '-',
  `Sortierung` smallint(6) DEFAULT '32000',
  `Sichtbar` char(1) DEFAULT '+',
  `Gewichtung` int(11) DEFAULT '1',
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Stundentafel_Faecher_IDX1` (`Stundentafel_ID`,`Fach_ID`),
  KEY `Stundentafel_IX` (`Stundentafel_ID`),
  KEY `Fach_IX` (`Fach_ID`),
  CONSTRAINT `Stundentafel_Faecher_ibfk_1` FOREIGN KEY (`Stundentafel_ID`) REFERENCES `Stundentafel` (`ID`),
  CONSTRAINT `Stundentafel_Faecher_ibfk_2` FOREIGN KEY (`Fach_ID`) REFERENCES `EigeneSchule_Faecher` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `TextExportVorlagen`
--

DROP TABLE IF EXISTS `TextExportVorlagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TextExportVorlagen` (
  `SchulnrEigner` int(11) NOT NULL,
  `VorlageName` varchar(50) NOT NULL,
  `Daten` text,
  PRIMARY KEY (`SchulnrEigner`,`VorlageName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Usergroups`
--

DROP TABLE IF EXISTS `Usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usergroups` (
  `UG_ID` int(11) NOT NULL,
  `UG_Bezeichnung` varchar(64) DEFAULT NULL,
  `UG_Kompetenzen` varchar(255) DEFAULT NULL,
  `UG_Nr` int(11) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  PRIMARY KEY (`UG_ID`),
  UNIQUE KEY `Usergroups_IX1` (`UG_Bezeichnung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `ID` int(11) NOT NULL,
  `US_Name` varchar(50) NOT NULL,
  `US_LoginName` varchar(20) NOT NULL,
  `US_Password` varchar(20) DEFAULT NULL,
  `US_UserGroups` varchar(50) DEFAULT NULL,
  `US_Privileges` varchar(255) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `EMail` varchar(100) DEFAULT NULL,
  `EMailName` varchar(100) DEFAULT NULL,
  `SMTPUsername` varchar(100) DEFAULT NULL,
  `SMTPPassword` varchar(100) DEFAULT NULL,
  `EMailSignature` text,
  `HeartbeatDate` int(11) DEFAULT NULL,
  `ComputerName` varchar(50) DEFAULT NULL,
  `US_PasswordHash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Users_IX1` (`US_LoginName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `Versetzung`
--

DROP TABLE IF EXISTS `Versetzung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Versetzung` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(150) DEFAULT NULL,
  `ASDKlasse` varchar(6) DEFAULT NULL,
  `Klasse` varchar(15) NOT NULL,
  `Jahrgang_ID` int(11) DEFAULT NULL,
  `FKlasse` varchar(15) DEFAULT NULL,
  `VKlasse` varchar(15) DEFAULT NULL,
  `OrgFormKrz` char(1) DEFAULT NULL,
  `KlassenlehrerKrz` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `StvKlassenlehrerKrz` varchar(10) DEFAULT NULL,
  `Restabschnitte` smallint(6) DEFAULT NULL,
  `ASDSchulformNr` varchar(4) DEFAULT NULL,
  `Fachklasse_ID` int(11) DEFAULT NULL,
  `PruefOrdnung` varchar(20) DEFAULT NULL,
  `Sichtbar` char(1) DEFAULT '+',
  `Sortierung` smallint(6) DEFAULT '32000',
  `Klassenart` varchar(4) DEFAULT NULL,
  `SommerSem` char(1) DEFAULT '-',
  `NotenGesperrt` varchar(1) DEFAULT NULL,
  `SchulnrEigner` int(11) DEFAULT NULL,
  `AdrMerkmal` varchar(1) DEFAULT 'A',
  `WebNotenGesperrt` varchar(1) DEFAULT '-',
  `KoopKlasse` varchar(1) DEFAULT '-',
  `Ankreuzzeugnisse` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Versetzung_IDX1` (`Klasse`),
  KEY `KlassenlehrerKrz_IX` (`KlassenlehrerKrz`),
  KEY `Fachklasse_IX` (`Fachklasse_ID`),
  CONSTRAINT `Versetzung_ibfk_1` FOREIGN KEY (`KlassenlehrerKrz`) REFERENCES `K_Lehrer` (`Kuerzel`),
  CONSTRAINT `Versetzung_ibfk_2` FOREIGN KEY (`Fachklasse_ID`) REFERENCES `EigeneSchule_Fachklassen` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ZuordnungReportvorlagen`
--

DROP TABLE IF EXISTS `ZuordnungReportvorlagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ZuordnungReportvorlagen` (
  `ID` int(11) NOT NULL,
  `SchulnrEigner` int(11) NOT NULL,
  `Jahrgang_ID` int(11) NOT NULL,
  `Abschluss` varchar(50) DEFAULT NULL,
  `AbschlussBB` varchar(50) DEFAULT NULL,
  `AbschlussArt` int(11) DEFAULT NULL,
  `VersetzungKrz` varchar(2) DEFAULT NULL,
  `Fachklasse_ID` int(11) DEFAULT NULL,
  `Reportvorlage` varchar(255) DEFAULT NULL,
  `Beschreibung` varchar(255) DEFAULT NULL,
  `Gruppe` varchar(50) DEFAULT NULL,
  `Zeugnisart` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

--
-- Create User UserAdmin without password
--

INSERT INTO Users
   (ID,US_Name,US_LoginName,US_Password,US_UserGroups,US_Privileges,SchulnrEigner,EMail,EMailName,SMTPUsername,SMTPPassword,EMailSignature,HeartbeatDate,ComputerName,US_PasswordHash)
VALUES
   (1,'Administrator','Admin',NULL,'1;2;3;4;5','$',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)

-- Dump completed on 2020-08-20 14:59:16

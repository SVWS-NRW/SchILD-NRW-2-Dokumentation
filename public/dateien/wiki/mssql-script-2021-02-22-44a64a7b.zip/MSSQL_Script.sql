﻿-- SQL Manager Lite for SQL Server 5.0.3.53390
-- ---------------------------------------
-- Host      : MSI-RICHTER
-- Database  : new_db
-- Version   : Microsoft SQL Server 2019 (RTM-GDR) (KB4517790) 15.0.2070.41


--
-- Definition for table K_Adressart : 
--

CREATE TABLE dbo.K_Adressart (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Adressart_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_AllgAdresse : 
--

CREATE TABLE dbo.K_AllgAdresse (
  ID int NOT NULL,
  AllgAdrAdressArt varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  AllgAdrName1 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrName2 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrStrasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrPLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrTelefon1 varchar(20) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrTelefon2 varchar(20) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrFax varchar(20) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrEmail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrBemerkungen varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  AllgAdrAusbildungsBetrieb varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  AllgAdrBietetPraktika varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  AllgAdrBranche varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrZusatz1 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrZusatz2 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  Massnahmentraeger varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  BelehrungISG varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NULL,
  ErwFuehrungszeugnis varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  ExtID varchar(50) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_AllgAdresse_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table AllgAdrAnsprechpartner : 
--

CREATE TABLE dbo.AllgAdrAnsprechpartner (
  ID int NOT NULL,
  Adresse_ID int NULL,
  Name varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Vorname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Anrede varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Telefon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  EMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Abteilung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  Titel varchar(15) COLLATE Latin1_General_CI_AS NULL,
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT Ansprechpartner_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule : 
--

CREATE TABLE dbo.EigeneSchule (
  ID int NULL,
  SchulformNr varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchulformKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchulformBez varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchultraegerArt varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SchultraegerNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Schulgliederung varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchulNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung1 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung2 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung3 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Strasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Ort varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Telefon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Fax varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Email varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Ganztags varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Schuljahr smallint NULL,
  SchuljahrAbschnitt smallint NULL,
  AnzahlAbschnitte smallint DEFAULT 2 NULL,
  Fremdsprachen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  UpdateSprachenfolge varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  JVAZeigen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  RefPaedagogikZeigen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  AnzJGS_Jahr smallint DEFAULT 1 NULL,
  AbschnittBez varchar(20) COLLATE Latin1_General_CI_AS DEFAULT 'Halbjahr' NULL,
  BezAbschnitt1 varchar(10) COLLATE Latin1_General_CI_AS DEFAULT '1. Hj' NULL,
  BezAbschnitt2 varchar(10) COLLATE Latin1_General_CI_AS DEFAULT '2. Hj' NULL,
  IstHauptsitz varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  NotenGesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  BezAbschnitt3 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  BezAbschnitt4 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  ZurueckgestelltAnzahl int NULL,
  ZurueckgestelltWeibl int NULL,
  ZurueckgestelltAuslaender int NULL,
  ZurueckgestelltAuslaenderWeibl int NULL,
  ZurueckgestelltAussiedler int NULL,
  ZurueckgestelltAussiedlerWeibl int NULL,
  TeamTeaching varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AbiGruppenprozess varchar(1) COLLATE Latin1_General_CI_AS NULL,
  DauerUnterrichtseinheit int NULL,
  Gruppen8Bis1 int NULL,
  Gruppen13Plus int NULL,
  InternatsplaetzeM int NULL,
  InternatsplaetzeW int NULL,
  InternatsplaetzeNeutral int NULL,
  SchulLogo image NULL,
  SchulnrEigner int NULL,
  SchulleiterName varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchulleiterVorname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  SchulleiterAmtsbez varchar(30) COLLATE Latin1_General_CI_AS NULL,
  SchulleiterGeschlecht int NULL,
  StvSchulleiterName varchar(50) COLLATE Latin1_General_CI_AS NULL,
  StvSchulleiterVorname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  StvSchulleiterAmtsbez varchar(30) COLLATE Latin1_General_CI_AS NULL,
  StvSchulleiterGeschlecht int NULL,
  Einstellungen text COLLATE Latin1_General_CI_AS NULL,
  Fehlstundenmodell_PrS1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'G' NULL,
  Fehlstundenmodell_S2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'F' NULL,
  Tendenznoten_S1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebKL_Modus varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'A' NULL,
  WebMahnungenGesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebNotenGesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  LogoFormat varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchILDweb_Config text COLLATE Latin1_General_CI_AS NULL,
  WebTeilLeistungenAnlegen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebInfoMail varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebAdresse varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Land varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Einstellungen2 text COLLATE Latin1_General_CI_AS NULL,
  SchulleiterTitel varchar(10) COLLATE Latin1_General_CI_AS NULL,
  StvSchulleiterTitel varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Fehlstundenmodell_S2BK varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'G' NULL,
  WebWarnungBis smalldatetime NULL,
  WebTeilLeistungenBis smalldatetime NULL,
  WebFehlstundenBis smalldatetime NULL,
  WebNoteneingabeVon smalldatetime NULL,
  WebNoteneingabeBis smalldatetime NULL,
  WebSpalteFBLESichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteFBLESpaltenTitel nvarchar(10) COLLATE Latin1_General_CI_AS DEFAULT 'FBLE' NULL,
  WebSpalteFBLEText nvarchar(64) COLLATE Latin1_General_CI_AS DEFAULT 'Fachbezogene Lernentwicklung' NULL,
  WebSpalteASVSichtbar nchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteASVSpaltenTitel nvarchar(10) COLLATE Latin1_General_CI_AS DEFAULT 'A&S' NULL,
  WebSpalteASVText nvarchar(64) COLLATE Latin1_General_CI_AS DEFAULT 'Arbeits- und Sozialverhalten' NULL,
  WebSpalteZBSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteZBSpaltenTitel nvarchar(10) COLLATE Latin1_General_CI_AS DEFAULT 'ZB' NULL,
  WebSpalteZBText nvarchar(64) COLLATE Latin1_General_CI_AS DEFAULT 'Zeugnis-Bemerkungen' NULL,
  WebSpalteLELSSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteLELSSpaltenTitel nvarchar(10) COLLATE Latin1_General_CI_AS DEFAULT 'AUE' NULL,
  WebSpalteLELSText nvarchar(64) COLLATE Latin1_General_CI_AS DEFAULT 'Ausserunterrichtliches Engagement an der Schule' NULL,
  WebSpalteESFSichtbar nchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebSpalteESFSpaltenTitel nvarchar(10) COLLATE Latin1_General_CI_AS DEFAULT 'ESF' NULL,
  WebSpalteESFText nvarchar(64) COLLATE Latin1_General_CI_AS DEFAULT 'Empfehlungsschreiben Fortsetzung' NULL,
  WebSpalteFBNWSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteFBGWSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebFoemaSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebFoemaEingabeBis smalldatetime NULL,
  WebFoemaAbJahr int NULL,
  WebFoemaAbAbschnitt int NULL,
  WebKonferenzAutoLogout int NULL,
  WebConfig text COLLATE Latin1_General_CI_AS NULL,
  SWNM_UpgradeVersion int DEFAULT 0 NULL,
  FuerSWNM nchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  DT_Web smalldatetime NULL,
  SchulLogoBase64 ntext COLLATE Latin1_General_CI_AS NULL
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table K_Lehrer : 
--

CREATE TABLE dbo.K_Lehrer (
  ID int NOT NULL,
  Kuerzel varchar(10) COLLATE Latin1_General_CI_AS NOT NULL,
  LIDKrz varchar(4) COLLATE Latin1_General_CI_AS NULL,
  Nachname varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Vorname varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Anrede varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Titel varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Geburtsdatum smalldatetime NULL,
  Geschlecht varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SerNr varchar(5) COLLATE Latin1_General_CI_AS NULL,
  StaatKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Rechtsverhaeltnis varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Beschaeftigungsart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Einsatzstatus varchar(1) COLLATE Latin1_General_CI_AS NULL,
  PflichtstdSoll float NULL,
  UnterrichtsStd float NULL,
  Strasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Tel varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Handy varchar(20) COLLATE Latin1_General_CI_AS NULL,
  EMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Statistik varchar(1) COLLATE Latin1_General_CI_AS NULL,
  StammschulNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  DatumZugang smalldatetime NULL,
  DatumAbgang smalldatetime NULL,
  GrundZugang varchar(10) COLLATE Latin1_General_CI_AS NULL,
  GrundAbgang varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulFunktion varchar(10) COLLATE Latin1_General_CI_AS NULL,
  MehrleistungStd float NULL,
  EntlastungStd float NULL,
  AnrechnungStd float NULL,
  RestStd float NULL,
  Amtsbezeichnung varchar(15) COLLATE Latin1_General_CI_AS NULL,
  IdentNr1 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NULL,
  Faecher varchar(100) COLLATE Latin1_General_CI_AS NULL,
  FuerExport varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  PersonTyp varchar(20) COLLATE Latin1_General_CI_AS DEFAULT 'LEHRKRAFT' NULL,
  LPassword varchar(255) COLLATE Latin1_General_CI_AS NULL,
  PWAktuell varchar(3) COLLATE Latin1_General_CI_AS DEFAULT '-;5' NULL,
  SchILDweb_FL varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchILDweb_KL varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchILDweb_Config text COLLATE Latin1_General_CI_AS NULL,
  EMailDienstlich varchar(100) COLLATE Latin1_General_CI_AS NULL,
  KennwortTools varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Antwort1 varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Antwort2 varchar(255) COLLATE Latin1_General_CI_AS NULL,
  KennwortToolsAktuell varchar(3) COLLATE Latin1_General_CI_AS DEFAULT '-;5' NULL,
  PANr varchar(20) COLLATE Latin1_General_CI_AS NULL,
  LBVNr varchar(15) COLLATE Latin1_General_CI_AS NULL,
  VSchluessel varchar(1) COLLATE Latin1_General_CI_AS NULL,
  MasernImpfnachweis varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchILDweb_SL nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchILDweb_KO nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchILDweb_KL_Noteneingabe nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchILDweb_KO_Noteneingabe nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchILDweb_SL_Noteneingabe nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchILDweb_NoteneingabeErlaubt nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  DT_Web smalldatetime NULL,
  Genehmigung_DA_ADV nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT K_Lehrer_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Abteilungen : 
--

CREATE TABLE dbo.EigeneSchule_Abteilungen (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  AbteilungsLeiter varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  Raum varchar(20) COLLATE Latin1_General_CI_AS NULL,
  EMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Durchwahl varchar(20) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT EigeneSchule_Abteilungen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Versetzung : 
--

CREATE TABLE dbo.Versetzung (
  ID int NOT NULL,
  Bezeichnung varchar(150) COLLATE Latin1_General_CI_AS NULL,
  ASDKlasse varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NOT NULL,
  Jahrgang_ID int NULL,
  FKlasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  VKlasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  OrgFormKrz varchar(1) COLLATE Latin1_General_CI_AS NULL,
  KlassenlehrerKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  StvKlassenlehrerKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Restabschnitte smallint NULL,
  ASDSchulformNr varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Fachklasse_ID int NULL,
  PruefOrdnung varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Klassenart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SommerSem varchar(1) COLLATE Latin1_General_CI_AS NULL,
  NotenGesperrt varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  AdrMerkmal varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'A' NULL,
  WebNotenGesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  KoopKlasse varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Ankreuzzeugnisse varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WebNotenGesperrtN nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebNoteneingabeVon smalldatetime NULL,
  WebNoteneingabeBis smalldatetime NULL,
  WebTeilLeistungenBis smalldatetime NULL,
  WebFehlstundenBis smalldatetime NULL,
  WebWarnungBis smalldatetime NULL,
  WebSpalteFBLSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteASVSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteZBSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteLELSSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteESFSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebFoemaSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebSpalteFBNWSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  WebSpalteFBGWSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  DT_Web smalldatetime NULL,
  WebWarnungVon smalldatetime NULL,
  WebSpalteFSPSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  WebSpalteVERSSichtbar nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT Versetzung_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Abt_Kl : 
--

CREATE TABLE dbo.EigeneSchule_Abt_Kl (
  ID int NOT NULL,
  Abteilung_ID int NOT NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NOT NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT EigeneSchule_Abt_Kl_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Fachklassen : 
--

CREATE TABLE dbo.EigeneSchule_Fachklassen (
  ID int NOT NULL,
  BKIndex smallint NULL,
  FKS varchar(3) COLLATE Latin1_General_CI_AS NULL,
  AP varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Kennung varchar(10) COLLATE Latin1_General_CI_AS NULL,
  FKS_AP_SIM varchar(5) COLLATE Latin1_General_CI_AS NULL,
  BKIndexTyp varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Beschreibung_W varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Status varchar(20) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  Lernfelder text COLLATE Latin1_General_CI_AS NULL,
  DQR_Niveau int NULL,
  Ebene1Klartext varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Ebene2Klartext varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Ebene3Klartext varchar(255) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT EigeneSchule_Fachklassen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Faecher : 
--

CREATE TABLE dbo.EigeneSchule_Faecher (
  ID int NOT NULL,
  FachKrz varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  ZeugnisBez varchar(255) COLLATE Latin1_General_CI_AS NULL,
  UeZeugnisBez varchar(255) COLLATE Latin1_General_CI_AS NULL,
  StatistikKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  BasisFach varchar(2) COLLATE Latin1_General_CI_AS NULL,
  IstSprache varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  SortierungS2 smallint DEFAULT 32000 NULL,
  NachprErlaubt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Gewichtung smallint DEFAULT 1 NULL,
  Fachgruppe_ID int NULL,
  Unterichtssprache varchar(1) COLLATE Latin1_General_CI_AS NULL,
  IstSchriftlich varchar(1) COLLATE Latin1_General_CI_AS NULL,
  IstSchriftlichBA varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AufZeugnis varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Lernfelder ntext COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  LK_Moegl varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Abi_Moegl varchar(1) COLLATE Latin1_General_CI_AS NULL,
  E1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  E2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Q1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Q2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Q3 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Q4 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AlsNeueFSinSII varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Leitfach_ID int NULL,
  Leitfach2_ID int NULL,
  Aufgabenfeld varchar(2) COLLATE Latin1_General_CI_AS NULL,
  AbgeschlFaecherHolen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  GewichtungFHR int NULL,
  E1_WZE int NULL,
  E2_WZE int NULL,
  Q_WZE int NULL,
  E1_S varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  E2_S varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  NurMuendlich varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  MaxBemZeichen int NULL,
  CONSTRAINT EigeneSchule_Faecher_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_FachTeilleistungen : 
--

CREATE TABLE dbo.EigeneSchule_FachTeilleistungen (
  SchulnrEigner int NOT NULL,
  Fach_ID int NOT NULL,
  Teilleistung_ID int NOT NULL,
  Kursart varchar(5) COLLATE Latin1_General_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Jahrgaenge : 
--

CREATE TABLE dbo.EigeneSchule_Jahrgaenge (
  ID int NOT NULL,
  InternKrz varchar(20) COLLATE Latin1_General_CI_AS NULL,
  ASDJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  ASDBezeichnung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  IstChronologisch varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Spaltentitel varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SekStufe varchar(6) COLLATE Latin1_General_CI_AS NULL,
  SGL varchar(3) COLLATE Latin1_General_CI_AS NULL,
  JahrgangNum smallint NULL,
  Restabschnitte int NULL,
  SchulnrEigner int NULL,
  Folgejahrgang_ID int NULL,
  CONSTRAINT EigeneSchule_Jahrgaenge_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_KAoADaten : 
--

CREATE TABLE dbo.EigeneSchule_KAoADaten (
  SchulnrEigner int NOT NULL,
  Curriculum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Koordinator varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Berufsorientierungsbuero varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  KooperationsvereinbarungAA varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  NutzungReflexionsworkshop varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  NutzungEntscheidungskompetenzI varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  NutzungEntscheidungskompetenzII varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Kursart : 
--

CREATE TABLE dbo.EigeneSchule_Kursart (
  ID int NOT NULL,
  Bezeichnung varchar(120) COLLATE Latin1_General_CI_AS NULL,
  InternBez varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Kursart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT EigeneSchule_Kursart_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_KursartAllg : 
--

CREATE TABLE dbo.EigeneSchule_KursartAllg (
  ID int NOT NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  InternBez varchar(20) COLLATE Latin1_General_CI_AS NULL,
  KursartASD varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Bezeichnung varchar(120) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT EigeneSchule_KursartAllg_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Merkmale : 
--

CREATE TABLE dbo.EigeneSchule_Merkmale (
  ID int NOT NULL,
  Schule varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Schueler varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Kurztext varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Langtext varchar(100) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Schulformen : 
--

CREATE TABLE dbo.EigeneSchule_Schulformen (
  ID int NOT NULL,
  SGL varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SF_SGL varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Schulform varchar(100) COLLATE Latin1_General_CI_AS NULL,
  DoppelQualifikation varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  BKIndex int NULL,
  SchulnrEigner int NULL,
  Schulform2 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT EigeneSchule_Schulformen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Teilstandorte : 
--

CREATE TABLE dbo.EigeneSchule_Teilstandorte (
  SchulnrEigner int NOT NULL,
  AdrMerkmal varchar(1) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Ort varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Strasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Hausnr varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Kuerzel varchar(30) COLLATE Latin1_General_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Texte : 
--

CREATE TABLE dbo.EigeneSchule_Texte (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Kuerzel varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Inhalt varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Beschreibung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  CONSTRAINT EigeneSchule_Texte_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Zertifikate : 
--

CREATE TABLE dbo.EigeneSchule_Zertifikate (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Kuerzel varchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  Bezeichnung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Fach varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Formatvorlage varchar(255) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT EigeneSchule_Zertifikate_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table EigeneSchule_Zertifikatsfaecher : 
--

CREATE TABLE dbo.EigeneSchule_Zertifikatsfaecher (
  Zertifikat_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Kuerzel varchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  Klartext varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Lernfelder text COLLATE Latin1_General_CI_AS NULL,
  MaxPunkte int NULL,
  Sortierung int NULL,
  CONSTRAINT EigeneSchule_ZF_PK PRIMARY KEY CLUSTERED (SchulnrEigner, Kuerzel)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table Fach_Gliederungen : 
--

CREATE TABLE dbo.Fach_Gliederungen (
  Fach_ID int NOT NULL,
  Gliederung varchar(3) COLLATE Latin1_General_CI_AS NOT NULL,
  SchulnrEigner int NOT NULL,
  Faechergruppe int NULL,
  GewichtungAB int NULL,
  GewichtungBB int NULL,
  SchriftlichAB varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchriftlichBB varchar(1) COLLATE Latin1_General_CI_AS NULL,
  GymOSFach varchar(1) COLLATE Latin1_General_CI_AS NULL,
  ZeugnisBez varchar(130) COLLATE Latin1_General_CI_AS NULL,
  Lernfelder ntext COLLATE Latin1_General_CI_AS NULL,
  Fachklasse_ID int DEFAULT 0 NULL,
  Sortierung int DEFAULT 32000 NULL
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table K_Schwerpunkt : 
--

CREATE TABLE dbo.K_Schwerpunkt (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Schwerpunkt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Fachklassen_Schwerpunkte : 
--

CREATE TABLE dbo.Fachklassen_Schwerpunkte (
  SchulnrEigner int NOT NULL,
  Fachklasse_ID int NOT NULL,
  Schwerpunkt_ID int NOT NULL,
  CONSTRAINT Fachklassen_Schwerpunkte_PK PRIMARY KEY CLUSTERED (SchulnrEigner, Fachklasse_ID, Schwerpunkt_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Floskelgruppen : 
--

CREATE TABLE dbo.Floskelgruppen (
  SchulnrEigner int NOT NULL,
  Kuerzel varchar(4) COLLATE Latin1_General_CI_AS NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Hauptgruppe varchar(4) COLLATE Latin1_General_CI_AS NULL,
  Farbe int NULL,
  CONSTRAINT Floskelgruppen_PK PRIMARY KEY CLUSTERED (SchulnrEigner, Kuerzel)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Floskeln : 
--

CREATE TABLE dbo.Floskeln (
  SchulnrEigner int NOT NULL,
  Kuerzel varchar(10) COLLATE Latin1_General_CI_AS NOT NULL,
  Floskeltext text COLLATE Latin1_General_CI_AS NOT NULL,
  Floskelgruppe varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Floskelfach varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Floskelniveau varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Floskeljahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table K_Ankreuzdaten : 
--

CREATE TABLE dbo.K_Ankreuzdaten (
  SchulnrEigner int NOT NULL,
  TextStufe1 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  TextStufe2 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  TextStufe3 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  TextStufe4 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  TextStufe5 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  BezeichnungSONST varchar(100) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_Ankreuzdaten_PK PRIMARY KEY CLUSTERED (SchulnrEigner)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Ankreuzfloskeln : 
--

CREATE TABLE dbo.K_Ankreuzfloskeln (
  ID bigint IDENTITY(1, 1) NOT NULL,
  SchulnrEigner int NOT NULL,
  Fach_ID int NOT NULL,
  Jahrgang varchar(2) COLLATE Latin1_General_CI_AS NOT NULL,
  Floskeltext varchar(255) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung int NULL,
  FachSortierung int NULL,
  Abschnitt int NULL,
  Aktiv varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Gliederung varchar(3) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_Ankreuzfloskeln_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_BeschaeftigungsArt : 
--

CREATE TABLE dbo.K_BeschaeftigungsArt (
  ID int NOT NULL,
  Bezeichnung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_BeschaeftigungsArt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Datenschutz : 
--

CREATE TABLE dbo.K_Datenschutz (
  ID bigint IDENTITY(1, 1) NOT NULL,
  Bezeichnung varchar(250) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Schluessel varchar(20) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NOT NULL,
  Sortierung int NULL,
  Beschreibung ntext COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_Datenschutz_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table K_EinschulungsArt : 
--

CREATE TABLE dbo.K_EinschulungsArt (
  ID int NOT NULL,
  Bezeichnung varchar(40) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_EinschulungsArt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Einzelleistungen : 
--

CREATE TABLE dbo.K_Einzelleistungen (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Gewichtung float NULL,
  CONSTRAINT K_Einzelleistungen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_EntlassGrund : 
--

CREATE TABLE dbo.K_EntlassGrund (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_EntlassGrund_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_ErzieherArt : 
--

CREATE TABLE dbo.K_ErzieherArt (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  ExportBez varchar(20) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_ErzieherArt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_ErzieherFunktion : 
--

CREATE TABLE dbo.K_ErzieherFunktion (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_ErzieherFunktion_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_FahrschuelerArt : 
--

CREATE TABLE dbo.K_FahrschuelerArt (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_FahrschuelerArt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Foerderschwerpunkt : 
--

CREATE TABLE dbo.K_Foerderschwerpunkt (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  StatistikKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Foerderschwerpunkt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Haltestelle : 
--

CREATE TABLE dbo.K_Haltestelle (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  EntfernungSchule float NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Haltestelle_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Kindergarten : 
--

CREATE TABLE dbo.K_Kindergarten (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Ort varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Strasse varchar(40) COLLATE Latin1_General_CI_AS NULL,
  Tel varchar(20) COLLATE Latin1_General_CI_AS NULL,
  EMail varchar(40) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Kindergarten_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Ort : 
--

CREATE TABLE dbo.K_Ort (
  ID int NOT NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Kreis varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 3200 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Land varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Ort_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Ortsteil : 
--

CREATE TABLE dbo.K_Ortsteil (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  OrtsteilSchluessel varchar(30) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_Ortsteil_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Religion : 
--

CREATE TABLE dbo.K_Religion (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  StatistikKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  ExportBez varchar(20) COLLATE Latin1_General_CI_AS NULL,
  ZeugnisBezeichnung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Religion_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Schule : 
--

CREATE TABLE dbo.K_Schule (
  ID int NOT NULL,
  SchulNr varchar(6) COLLATE Latin1_General_CI_AS NOT NULL,
  Name varchar(100) COLLATE Latin1_General_CI_AS NULL,
  SchulformNr varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchulformKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  SchulformBez varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Strasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Ort varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Telefon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Fax varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Email varchar(40) COLLATE Latin1_General_CI_AS NULL,
  Schulleiter varchar(40) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulNr_SIM varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Kuerzel varchar(10) COLLATE Latin1_General_CI_AS NULL,
  KurzBez varchar(40) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Schule_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Schulfunktionen : 
--

CREATE TABLE dbo.K_Schulfunktionen (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Schulfunktionen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Sportbefreiung : 
--

CREATE TABLE dbo.K_Sportbefreiung (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Sportbefreiung_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Staat : 
--

CREATE TABLE dbo.K_Staat (
  ID int NOT NULL,
  Bezeichnung varchar(80) COLLATE Latin1_General_CI_AS NOT NULL,
  StatistikKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  ExportBez varchar(20) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  Bezeichnung2 varchar(80) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT K_Staat_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_TelefonArt : 
--

CREATE TABLE dbo.K_TelefonArt (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_TelefonArt_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Verkehrssprachen : 
--

CREATE TABLE dbo.K_Verkehrssprachen (
  ID int NOT NULL,
  Kurztext varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Langtext varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table K_Vermerkart : 
--

CREATE TABLE dbo.K_Vermerkart (
  ID int NOT NULL,
  Bezeichnung varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Aenderbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT K_Vermerkart_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table K_Zertifikate : 
--

CREATE TABLE dbo.K_Zertifikate (
  Kuerzel varchar(5) COLLATE Latin1_General_CI_AS NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  SchulnrEigner int NOT NULL,
  CONSTRAINT K_Zertifikate_PK PRIMARY KEY CLUSTERED (Kuerzel, SchulnrEigner)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Kompetenzen : 
--

CREATE TABLE dbo.Kompetenzen (
  KO_ID int NOT NULL,
  KO_Gruppe int NOT NULL,
  KO_Bezeichnung varchar(64) COLLATE Latin1_General_CI_AS NOT NULL,
  CONSTRAINT Kompetenzen_PK PRIMARY KEY CLUSTERED (KO_ID, KO_Gruppe)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Kompetenzgruppen : 
--

CREATE TABLE dbo.Kompetenzgruppen (
  KG_Spalte int NOT NULL,
  KG_Zeile int NOT NULL,
  KG_ID int NOT NULL,
  KG_Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  CONSTRAINT Kompetenzgruppen_PK PRIMARY KEY CLUSTERED (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Kurse : 
--

CREATE TABLE dbo.Kurse (
  ID int NOT NULL,
  Jahr smallint NOT NULL,
  Abschnitt smallint NOT NULL,
  KurzBez varchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  Jahrgang_ID int NULL,
  ASDJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Fach_ID int NOT NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Wochenstd smallint NULL,
  LehrerKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Schienen varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Fortschreibungsart varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WochenstdKL float NULL,
  Schulnr int NULL,
  EpochU varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchulnrEigner int NULL,
  Zeugnisbez varchar(130) COLLATE Latin1_General_CI_AS NULL,
  Jahrgaenge varchar(50) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT Kurse_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table KursKombinationen : 
--

CREATE TABLE dbo.KursKombinationen (
  Kurs1_ID int NOT NULL,
  Kurs2_ID int NOT NULL,
  CONSTRAINT KursKombi_PK PRIMARY KEY CLUSTERED (Kurs1_ID, Kurs2_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table KursLehrer : 
--

CREATE TABLE dbo.KursLehrer (
  Kurs_ID int NOT NULL,
  Lehrer_ID int NOT NULL,
  Anteil float NULL,
  SchulnrEigner int NULL,
  CONSTRAINT PrimaryKey PRIMARY KEY CLUSTERED (Kurs_ID, Lehrer_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Lehrer_IMEI : 
--

CREATE TABLE dbo.Lehrer_IMEI (
  ID int NOT NULL,
  Lehrer_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  IMEI varchar(20) COLLATE Latin1_General_CI_AS NULL,
  IMEI2 nvarchar(50) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung nvarchar(255) COLLATE Latin1_General_CI_AS NULL,
  GeraetGesperrt nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  AppEntsperrungMoeglich nvarchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT Lehrer_IMEI_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerAbschnittsdaten : 
--

CREATE TABLE dbo.LehrerAbschnittsdaten (
  Lehrer_ID int NOT NULL,
  Jahr int NOT NULL,
  Abschnitt int NOT NULL,
  Rechtsverhaeltnis varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Beschaeftigungsart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Einsatzstatus varchar(1) COLLATE Latin1_General_CI_AS NULL,
  PflichtstdSoll float NULL,
  UnterrichtsStd float NULL,
  MehrleistungStd float NULL,
  EntlastungStd float NULL,
  AnrechnungStd float NULL,
  RestStd float NULL,
  SchulnrEigner int NULL,
  CONSTRAINT LehrerAbschnittsdaten_PK PRIMARY KEY CLUSTERED (Lehrer_ID, Jahr, Abschnitt)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerAnrechnung : 
--

CREATE TABLE dbo.LehrerAnrechnung (
  Lehrer_ID int NOT NULL,
  AnrechnungsgrundKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  AnrechnungStd float NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerEntlastung : 
--

CREATE TABLE dbo.LehrerEntlastung (
  Lehrer_ID int NOT NULL,
  EntlastungsgrundKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  EntlastungStd float NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerFotos : 
--

CREATE TABLE dbo.LehrerFotos (
  Lehrer_ID int NOT NULL,
  Foto image NULL,
  SchulnrEigner int NULL,
  FotoBase64 ntext COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT LehrerFotos_PK PRIMARY KEY CLUSTERED (Lehrer_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table LehrerFunktionen : 
--

CREATE TABLE dbo.LehrerFunktionen (
  Lehrer_ID int NOT NULL,
  Jahr int NULL,
  Abschnitt int NOT NULL,
  Funktion_ID int NOT NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerLehramt : 
--

CREATE TABLE dbo.LehrerLehramt (
  Lehrer_ID int NOT NULL,
  LehramtKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LehramtAnerkennungKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerLehramtFachr : 
--

CREATE TABLE dbo.LehrerLehramtFachr (
  Lehrer_ID int NOT NULL,
  LehramtKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  FachrKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  FachrAnerkennungKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerLehramtLehrbef : 
--

CREATE TABLE dbo.LehrerLehramtLehrbef (
  Lehrer_ID int NOT NULL,
  LehramtKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LehrbefKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LehrbefAnerkennungKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table LehrerMehrleistung : 
--

CREATE TABLE dbo.LehrerMehrleistung (
  Lehrer_ID int NOT NULL,
  MehrleistungsgrundKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  MehrleistungStd float NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table Logins : 
--

CREATE TABLE dbo.Logins (
  LI_UserID int NOT NULL,
  LI_LoginTime smalldatetime NULL,
  LI_LogOffTime smalldatetime NULL,
  SchulnrEigner int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table NichtMoeglAbiFachKombi : 
--

CREATE TABLE dbo.NichtMoeglAbiFachKombi (
  Fach1_ID int NOT NULL,
  Fach2_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Kursart1 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Kursart2 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  PK varchar(30) COLLATE Latin1_General_CI_AS NOT NULL,
  Sortierung int NULL,
  Phase varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Typ varchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT NichtMoeglAbiFachKombi_PK PRIMARY KEY CLUSTERED (PK)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Personengruppen : 
--

CREATE TABLE dbo.Personengruppen (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Gruppenname varchar(100) COLLATE Latin1_General_CI_AS NOT NULL,
  Zusatzinfo varchar(100) COLLATE Latin1_General_CI_AS NULL,
  SammelEMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  GruppenArt varchar(20) COLLATE Latin1_General_CI_AS NULL,
  XMLExport varchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT Personengruppen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Personengruppen_Personen : 
--

CREATE TABLE dbo.Personengruppen_Personen (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Gruppe_ID int NOT NULL,
  Person_ID int NULL,
  PersonNr int NULL,
  PersonArt varchar(1) COLLATE Latin1_General_CI_AS NULL,
  PersonName varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  PersonVorname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  PersonPLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  PersonOrt varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PersonStrasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PersonTelefon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  PersonMobil varchar(20) COLLATE Latin1_General_CI_AS NULL,
  PersonEMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  ZusatzInfo varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int NULL,
  PersonAnrede varchar(10) COLLATE Latin1_General_CI_AS NULL,
  PersonAkadGrad varchar(15) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT Personengruppen_Personen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table PrfSemAbschl : 
--

CREATE TABLE dbo.PrfSemAbschl (
  Nr varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Klartext varchar(30) COLLATE Latin1_General_CI_AS NULL,
  StatistikKrz varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Sortierung smallint DEFAULT 32000 NULL
)
ON [PRIMARY]
GO

--
-- Definition for table Schild_Verwaltung : 
--

CREATE TABLE dbo.Schild_Verwaltung (
  BackupDatum smalldatetime NULL,
  AutoBerechnung smalldatetime NULL,
  DatumStatkue smalldatetime NULL,
  DatumSchildIntern smalldatetime NULL,
  Bescheinigung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Stammblatt varchar(255) COLLATE Latin1_General_CI_AS NULL,
  DatenGeprueft varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  FaecherUebernehmen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Version varchar(10) COLLATE Latin1_General_CI_AS NULL,
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NULL,
  StatistikJahr int NULL,
  SchulnrEigner int NULL,
  LD_Datentyp varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Version3 varchar(16) COLLATE Latin1_General_CI_AS NULL,
  DatumLoeschfristHinweisDeaktiviert smalldatetime NULL,
  DatumLoeschfristHinweisDeaktiviertUserID int NULL,
  DatumDatenGeloescht smalldatetime NULL
)
ON [PRIMARY]
GO

--
-- Definition for table SchildFilter : 
--

CREATE TABLE dbo.SchildFilter (
  ID int NOT NULL,
  Art varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Name varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Beschreibung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Tabellen varchar(255) COLLATE Latin1_General_CI_AS NULL,
  ZusatzTabellen varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Bedingung ntext COLLATE Latin1_General_CI_AS NULL,
  BedingungKlartext ntext COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchildFilter_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table Schueler : 
--

CREATE TABLE dbo.Schueler (
  ID int NOT NULL,
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NULL,
  SrcID int NULL,
  IDext varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Status int NULL,
  Name varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Vorname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Zusatz varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Geburtsname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Strasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  PLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  OrtAbk varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Ortsteil_ID int NULL,
  Telefon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Email varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Fax varchar(20) COLLATE Latin1_General_CI_AS NULL,
  AktSchuljahr smallint NULL,
  AktAbschnitt smallint NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Jahrgang smallint NULL,
  PruefOrdnung varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Geburtsdatum smalldatetime NULL,
  Geburtsort varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Volljaehrig varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Geschlecht smallint NULL,
  StaatKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  StaatKrz2 varchar(3) COLLATE Latin1_General_CI_AS NULL,
  StaatAbk varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Aussiedler varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Religion_ID int NULL,
  ReligionAbk varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Religionsabmeldung smalldatetime NULL,
  Religionsanmeldung smalldatetime NULL,
  Bafoeg varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Schwerbehinderung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Foerderschwerpunkt_ID int NULL,
  Sportbefreiung_ID int NULL,
  Fahrschueler_ID int NULL,
  Haltestelle_ID int NULL,
  HaltestelleAbk varchar(30) COLLATE Latin1_General_CI_AS NULL,
  ASDSchulform varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Jahrgang_ID int NULL,
  ASDJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Fachklasse_ID int NULL,
  SchulpflichtErf varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Anschreibdatum smalldatetime NULL,
  Aufnahmedatum smalldatetime NULL,
  Einschulungsjahr smallint NULL,
  Einschulungsart_ID int NULL,
  LSSchulNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  LSSchulformSIM varchar(3) COLLATE Latin1_General_CI_AS NULL,
  LSJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSSchulentlassDatum smalldatetime NULL,
  LSVersetzung varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSFachklKennung varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LSFachklSIM varchar(5) COLLATE Latin1_General_CI_AS NULL,
  LSEntlassgrund varchar(50) COLLATE Latin1_General_CI_AS NULL,
  LSEntlassArt varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSKlassenart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSRefPaed varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Entlassjahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Entlassjahrgang_ID int NULL,
  Entlassdatum smalldatetime NULL,
  Entlassgrund varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Entlassart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SchulwechselNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Schulwechseldatum smalldatetime NULL,
  Geloescht varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Gesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  ModifiziertAm smalldatetime NULL,
  ModifiziertVon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Markiert varchar(21) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  FotoVorhanden varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  JVA varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  RefPaed varchar(1) COLLATE Latin1_General_CI_AS NULL,
  KeineAuskunft varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Lehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Beruf varchar(100) COLLATE Latin1_General_CI_AS NULL,
  AbschlussDatum varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Bemerkungen ntext COLLATE Latin1_General_CI_AS NULL,
  BeginnBildungsgang smalldatetime NULL,
  Durchschnitt varchar(4) COLLATE Latin1_General_CI_AS NULL,
  OrgFormKrz varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Klassenart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  DurchschnittsNote varchar(4) COLLATE Latin1_General_CI_AS NULL,
  LSSGL varchar(5) COLLATE Latin1_General_CI_AS NULL,
  LSSchulform varchar(2) COLLATE Latin1_General_CI_AS NULL,
  KonfDruck varchar(1) COLLATE Latin1_General_CI_AS NULL,
  DSN_Text varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Berufsabschluss varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Schwerpunkt_ID int NULL,
  LSSGL_SIM varchar(3) COLLATE Latin1_General_CI_AS NULL,
  BerufsschulpflErf varchar(1) COLLATE Latin1_General_CI_AS NULL,
  StatusNSJ int NULL,
  FachklasseNSJ_ID int NULL,
  Buchkonto float NULL,
  VerkehrsspracheFamilie varchar(2) COLLATE Latin1_General_CI_AS NULL,
  JahrZuzug int NULL,
  DauerKindergartenbesuch varchar(1) COLLATE Latin1_General_CI_AS NULL,
  VerpflichtungSprachfoerderkurs varchar(1) COLLATE Latin1_General_CI_AS NULL,
  TeilnahmeSprachfoerderkurs varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Schulbuchgeldbefreit varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Autist varchar(1) COLLATE Latin1_General_CI_AS NULL,
  GeburtslandSchueler varchar(10) COLLATE Latin1_General_CI_AS NULL,
  GeburtslandVater varchar(10) COLLATE Latin1_General_CI_AS NULL,
  GeburtslandMutter varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Uebergangsempfehlung_JG5 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  ErsteSchulform_SI varchar(10) COLLATE Latin1_General_CI_AS NULL,
  JahrWechsel_SI int NULL,
  JahrWechsel_SII int NULL,
  Migrationshintergrund varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Foerderschwerpunkt2_ID int NULL,
  SortierungKlasse int NULL,
  ExterneSchulnr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  Kindergarten_ID int NULL,
  LetzterBerufsAbschluss varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LetzterAllgAbschluss varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Land varchar(2) COLLATE Latin1_General_CI_AS NULL,
  AV_Leist int NULL,
  AV_Zuv int NULL,
  AV_Selbst int NULL,
  SV_Verant int NULL,
  SV_Konfl int NULL,
  SV_Koop int NULL,
  Duplikat varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  EinschulungsartASD varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Hausnr varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Strassenname varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  BilingualerZweig varchar(1) COLLATE Latin1_General_CI_AS NULL,
  DurchschnittsnoteFHR varchar(4) COLLATE Latin1_General_CI_AS NULL,
  DSN_FHR_Text varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Eigenanteil float NULL,
  StaatAbk2 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  ZustimmungFoto varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  BKAZVO int NULL,
  HatBerufsausbildung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Ausweisnummer varchar(30) COLLATE Latin1_General_CI_AS NULL,
  AOSF varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  EPJahre int DEFAULT 2 NULL,
  LSBemerkung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  WechselBestaetigt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  DauerBildungsgang int NULL,
  AnmeldeDatum smalldatetime NULL,
  MeisterBafoeg varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  OnlineAnmeldung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Dokumentenverzeichnis varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Berufsqualifikation varchar(100) COLLATE Latin1_General_CI_AS NULL,
  HausnrZusatz varchar(30) COLLATE Latin1_General_CI_AS NULL,
  ZieldifferentesLernen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  ZusatzNachname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  EndeEingliederung smalldatetime NULL,
  SchulEmail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  EndeAnschlussfoerderung smalldatetime NULL,
  MasernImpfnachweis varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Lernstandsbericht varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SprachfoerderungVon smalldatetime NULL,
  SprachfoerderungBis smalldatetime NULL,
  CONSTRAINT Schueler_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table Schueler_AllgAdr : 
--

CREATE TABLE dbo.Schueler_AllgAdr (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Adresse_ID int NOT NULL,
  Vertragsart_ID int NULL,
  Vertragsbeginn smalldatetime NULL,
  Vertragsende smalldatetime NULL,
  Ausbilder varchar(30) COLLATE Latin1_General_CI_AS NULL,
  AllgAdrAnschreiben varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Praktikum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Sortierung int NULL,
  Ansprechpartner_ID int NULL,
  Betreuungslehrer_ID int NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerAllgAdr_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerAbgaenge : 
--

CREATE TABLE dbo.SchuelerAbgaenge (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  BemerkungIntern varchar(30) COLLATE Latin1_General_CI_AS NULL,
  AbgangsSchulform varchar(2) COLLATE Latin1_General_CI_AS NULL,
  AbgangsBeschreibung varchar(200) COLLATE Latin1_General_CI_AS NULL,
  OrganisationsformKrz varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AbgangsSchule varchar(100) COLLATE Latin1_General_CI_AS NULL,
  AbgangsSchuleAnschr varchar(100) COLLATE Latin1_General_CI_AS NULL,
  AbgangsSchulNr varchar(6) COLLATE Latin1_General_CI_AS NULL,
  LSJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSEntlassArt varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSSchulformSIM varchar(3) COLLATE Latin1_General_CI_AS NULL,
  LSSchulEntlassDatum smalldatetime NULL,
  LSVersetzung varchar(2) COLLATE Latin1_General_CI_AS NULL,
  LSSGL varchar(5) COLLATE Latin1_General_CI_AS NULL,
  LSFachklKennung varchar(10) COLLATE Latin1_General_CI_AS NULL,
  LSFachklSIM varchar(5) COLLATE Latin1_General_CI_AS NULL,
  FuerSIMExport varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  LSBeginnDatum smalldatetime NULL,
  LSBeginnJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerAbgaenge_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerAbiFaecher : 
--

CREATE TABLE dbo.SchuelerAbiFaecher (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Fach_ID int NOT NULL,
  FachKrz varchar(20) COLLATE Latin1_General_CI_AS NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  AbiFach varchar(1) COLLATE Latin1_General_CI_AS NULL,
  P12_1 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  H12_1 int NULL,
  R12_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  S12_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  P12_2 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  H12_2 int NULL,
  R12_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  S12_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  P13_1 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  H13_1 int NULL,
  R13_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  S13_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  P13_2 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  H13_2 int NULL,
  R13_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  S13_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Zulassung smallint NULL,
  Durchschnitt float NULL,
  AbiPruefErgebnis smallint NULL,
  Zwischenstand smallint NULL,
  MdlPflichtPruefung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  MdlFreiwPruefung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  MdlPruefErgebnis smallint NULL,
  MdlPruefFolge smallint NULL,
  AbiErgebnis smallint NULL,
  MdlBestPruefung varchar(1) COLLATE Latin1_General_CI_AS NULL,
  W12_1 int NULL,
  W12_2 int NULL,
  W13_1 int NULL,
  W13_2 int NULL,
  P_FA varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Gekoppelt varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Kurs_ID int NULL,
  FSortierung int NULL,
  SchulnrEigner int NULL,
  Fachlehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  P11_1 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  P11_2 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  S11_1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  S11_2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  R_FA varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT SchuelerAbiFaecher_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerAbitur : 
--

CREATE TABLE dbo.SchuelerAbitur (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Zugelassen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SummeGK smallint NULL,
  SummeLK smallint NULL,
  SummenOK smallint NULL,
  PruefungBestanden varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Note varchar(3) COLLATE Latin1_General_CI_AS NULL,
  GesamtPunktzahl smallint NULL,
  Notensprung smallint NULL,
  FehlendePunktzahl smallint NULL,
  AnzRelLK smallint NULL,
  AnzRelGK smallint NULL,
  AnzRelOK smallint NULL,
  AnzDefLK smallint NULL,
  AnzDefGK smallint NULL,
  BesondereLernleistung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Latinum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  KlLatinum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Graecum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Hebraicum varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  FranzBilingual varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  FehlStd int NULL,
  uFehlStd int NULL,
  SchulnrEigner int NULL,
  BLL_Art varchar(1) COLLATE Latin1_General_CI_AS DEFAULT 'K' NULL,
  BLL_Punkte int NULL,
  FS2_SekI_manuell varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Punktsumme_II int NULL,
  Defizite_II int NULL,
  LK_Defizite_II int NULL,
  Thema_BLL varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Thema_PJK varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Punktsumme_I int NULL,
  Defizite_I int NULL,
  LK_Defizite_I int NULL,
  Kurse_I int NULL,
  FA_Punkte int NULL,
  FA_Fach varchar(130) COLLATE Latin1_General_CI_AS NULL,
  AnzahlKurse_0 int NULL,
  Durchschnitt_I float NULL,
  CONSTRAINT SchuelerAbitur_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerAnkreuzfloskeln : 
--

CREATE TABLE dbo.SchuelerAnkreuzfloskeln (
  ID bigint IDENTITY(1, 1) NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Jahr int NOT NULL,
  Abschnitt int NOT NULL,
  Floskel_ID int NOT NULL,
  Stufe1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Stufe2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Stufe3 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Stufe4 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Stufe5 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerAnkreuzfloskeln_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerBKAbschluss : 
--

CREATE TABLE dbo.SchuelerBKAbschluss (
  Schueler_ID int NOT NULL,
  Zulassung char(1) COLLATE Latin1_General_CI_AS NULL,
  Bestanden char(1) COLLATE Latin1_General_CI_AS NULL,
  Zeugnis char(1) COLLATE Latin1_General_CI_AS NULL,
  ZertifikatBK char(1) COLLATE Latin1_General_CI_AS NULL,
  ZulassungErwBK char(1) COLLATE Latin1_General_CI_AS NULL,
  BestandenErwBK char(1) COLLATE Latin1_General_CI_AS NULL,
  ZulassungBA char(1) COLLATE Latin1_General_CI_AS NULL,
  BestandenBA char(1) COLLATE Latin1_General_CI_AS NULL,
  PraktPrfNote varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NoteKolloquium varchar(2) COLLATE Latin1_General_CI_AS NULL,
  ThemaAbschlussarbeit ntext COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  BAP_Vorhanden varchar(1) COLLATE Latin1_General_CI_AS NULL,
  NoteFachpraxis varchar(2) COLLATE Latin1_General_CI_AS NULL,
  FachPraktAnteilAusr varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  CONSTRAINT SchuelerBKAbschluss_PK PRIMARY KEY CLUSTERED (Schueler_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerBKFaecher : 
--

CREATE TABLE dbo.SchuelerBKFaecher (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Fach_ID int NOT NULL,
  FachKrz varchar(20) COLLATE Latin1_General_CI_AS NULL,
  FachSchriftlich char(1) COLLATE Latin1_General_CI_AS NULL,
  FachSchriftlichBA char(1) COLLATE Latin1_General_CI_AS NULL,
  Vornote varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NoteSchriftlich varchar(2) COLLATE Latin1_General_CI_AS NULL,
  MdlPruefung char(1) COLLATE Latin1_General_CI_AS NULL,
  MdlPruefungFW char(1) COLLATE Latin1_General_CI_AS NULL,
  NoteMuendlich varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NoteAbschluss varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NotePrfGesamt varchar(2) COLLATE Latin1_General_CI_AS NULL,
  FSortierung int NULL,
  SchulnrEigner int NULL,
  Fachlehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  NoteAbschlussBA varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Kursart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  CONSTRAINT SchuelerBKFaecher_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerDatenschutz : 
--

CREATE TABLE dbo.SchuelerDatenschutz (
  Schueler_ID int NOT NULL,
  Datenschutz_ID int NOT NULL,
  Status varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  SchulnrEigner int NOT NULL,
  CONSTRAINT SchuelerDatenschutz_PK PRIMARY KEY CLUSTERED (Schueler_ID, Datenschutz_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerEinzelleistungen : 
--

CREATE TABLE dbo.SchuelerEinzelleistungen (
  SchulnrEigner int NOT NULL,
  ID bigint IDENTITY(1, 1) NOT NULL,
  Datum smalldatetime NULL,
  Lehrer_ID int NULL,
  Art_ID int NULL,
  Bemerkung varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Leistung_ID bigint NULL,
  NotenKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerEinzelleistungen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerErzAdr : 
--

CREATE TABLE dbo.SchuelerErzAdr (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  ErzieherArt_ID int NULL,
  Anrede1 varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Titel1 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Name1 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Vorname1 varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Anrede2 varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Titel2 varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Name2 varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Vorname2 varchar(30) COLLATE Latin1_General_CI_AS NULL,
  ErzStrasse varchar(50) COLLATE Latin1_General_CI_AS NULL,
  ErzPLZ varchar(10) COLLATE Latin1_General_CI_AS NULL,
  ErzOrtsteil_ID int NULL,
  ErzAnschreiben varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  ErzBemerkung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int NULL,
  ErzEMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  ErzAdrZusatz varchar(50) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  Erz1StaatKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Erz2StaatKrz varchar(3) COLLATE Latin1_General_CI_AS NULL,
  ErzEMail2 varchar(100) COLLATE Latin1_General_CI_AS NULL,
  Erz1ZusatzNachname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Erz2ZusatzNachname varchar(30) COLLATE Latin1_General_CI_AS NULL,
  Bemerkungen text COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerErzAdr_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerErzFunktion : 
--

CREATE TABLE dbo.SchuelerErzFunktion (
  ID int NOT NULL,
  Erzieher_ID int NOT NULL,
  Funktion_ID int NOT NULL,
  Person smallint NULL,
  Klasse varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerErzFunktion_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerLernabschnittsdaten : 
--

CREATE TABLE dbo.SchuelerLernabschnittsdaten (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Jahr smallint NOT NULL,
  Abschnitt smallint NOT NULL,
  Bildungsgang varchar(1) COLLATE Latin1_General_CI_AS NOT NULL,
  WechselNr smallint NOT NULL,
  Jahrgang smallint NULL,
  Hochrechnung int NULL,
  SemesterWertung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  PruefOrdnung varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Verspaetet smallint NULL,
  NPV_Fach_ID int NULL,
  NPV_NoteKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NPV_Datum smalldatetime NULL,
  NPAA_Fach_ID int NULL,
  NPAA_NoteKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NPAA_Datum smalldatetime NULL,
  NPBQ_Fach_ID int NULL,
  NPBQ_NoteKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  NPBQ_Datum smalldatetime NULL,
  VersetzungKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  AbschlussArt smallint NULL,
  AbschlIstPrognose varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Konferenzdatum smalldatetime NULL,
  ZeugnisDatum smalldatetime NULL,
  KlassenLehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  ASDSchulgliederung varchar(3) COLLATE Latin1_General_CI_AS NULL,
  ASDJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Jahrgang_ID int NULL,
  Fachklasse_ID int NULL,
  Schwerpunkt_ID int NULL,
  ZeugnisBem ntext COLLATE Latin1_General_CI_AS NULL,
  Schwerbehinderung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Foerderschwerpunkt_ID int NULL,
  OrgFormKrz varchar(1) COLLATE Latin1_General_CI_AS NULL,
  RefPaed varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Klassenart varchar(2) COLLATE Latin1_General_CI_AS NULL,
  SumFehlStd int NULL,
  SumFehlStdU int NULL,
  Wiederholung varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Gesamtnote_GS int NULL,
  Gesamtnote_NW int NULL,
  Folgeklasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Foerderschwerpunkt2_ID int NULL,
  Abschluss varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Abschluss_B varchar(50) COLLATE Latin1_General_CI_AS NULL,
  DSNote varchar(4) COLLATE Latin1_General_CI_AS NULL,
  AV_Leist int NULL,
  AV_Zuv int NULL,
  AV_Selbst int NULL,
  SV_Verant int NULL,
  SV_Konfl int NULL,
  SV_Koop int NULL,
  KN_Lehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  StvKlassenlehrer_ID int NULL,
  MoeglNPFaecher ntext COLLATE Latin1_General_CI_AS NULL,
  Zertifikate varchar(30) COLLATE Latin1_General_CI_AS NULL,
  DatumFHR smalldatetime NULL,
  PruefAlgoErgebnis text COLLATE Latin1_General_CI_AS NULL,
  Zeugnisart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  DatumVon smalldatetime NULL,
  DatumBis smalldatetime NULL,
  FehlstundenGrenzwert int NULL,
  EingabeFertig nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  Sonderpaedagoge_ID int NULL,
  FachPraktAnteilAusr varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT SchuelerLernabschnittsdaten_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerFehlstunden : 
--

CREATE TABLE dbo.SchuelerFehlstunden (
  ID bigint IDENTITY(1, 1) NOT NULL,
  SchulnrEigner int NOT NULL,
  Abschnitt_ID int NOT NULL,
  Datum smalldatetime NOT NULL,
  Fach_ID int NULL,
  Fehlstd float NOT NULL,
  VonStd int NULL,
  BisStd int NULL,
  Entschuldigt varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Lehrer_ID int NULL,
  GU_ID nvarchar(40) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerFehlstunden_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerFHR : 
--

CREATE TABLE dbo.SchuelerFHR (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  FHRErreicht varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Note varchar(3) COLLATE Latin1_General_CI_AS NULL,
  GesamtPunktzahl smallint NULL,
  SummeGK smallint NULL,
  SummeLK smallint NULL,
  SummenOK smallint NULL,
  AnzRelLK smallint NULL,
  AnzRelGK smallint NULL,
  AnzRelOK smallint NULL,
  AnzDefLK smallint NULL,
  AnzDefGK smallint NULL,
  AnzDefOK smallint NULL,
  JSII_2_1 smallint NULL,
  JSII_2_1_W smallint NULL,
  JSII_2_2 smallint NULL,
  JSII_2_2_W smallint NULL,
  JSII_3_1 smallint NULL,
  JSII_3_1_W smallint NULL,
  JSII_3_2 smallint NULL,
  JSII_3_2_W smallint NULL,
  ASII_2_1 smallint NULL,
  ASII_2_2 smallint NULL,
  ASII_2_1_W smallint NULL,
  ASII_2_2_W smallint NULL,
  ASII_3_1 smallint NULL,
  ASII_3_2 smallint NULL,
  ASII_3_1_W smallint NULL,
  ASII_3_2_W smallint NULL,
  WSII_2_1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_2_2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_2_1_W varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_2_2_W varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_3_1 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_3_2 varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_3_1_W varchar(1) COLLATE Latin1_General_CI_AS NULL,
  WSII_3_2_W varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerFHR_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerFHRFaecher : 
--

CREATE TABLE dbo.SchuelerFHRFaecher (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Fach_ID int NOT NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  FachKrz varchar(20) COLLATE Latin1_General_CI_AS NULL,
  PSII_2_1 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_2_1 int NULL,
  RSII_2_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_2_2 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_2_2 int NULL,
  RSII_2_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_2_1_W varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_2_1_W int NULL,
  RSII_2_1_W varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_2_2_W varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_2_2_W int NULL,
  RSII_2_2_W varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_3_1 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_3_1 int NULL,
  RSII_3_1 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_3_2 varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_3_2 int NULL,
  RSII_3_2 varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_3_1_W varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_3_1_W int NULL,
  RSII_3_1_W varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  PSII_3_2_W varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HSII_3_2_W int NULL,
  RSII_3_2_W varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  KSII_2_1 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_2_2 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_2_1_W varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_2_2_W varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_3_1 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_3_2 varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_3_1_W varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KSII_3_2_W varchar(5) COLLATE Latin1_General_CI_AS NULL,
  FSortierung int NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerFHRFaecher_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerFoerderempfehlungen : 
--

CREATE TABLE dbo.SchuelerFoerderempfehlungen (
  GU_ID varchar(40) COLLATE Latin1_General_CI_AS NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  DatumAngelegt smalldatetime NOT NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  Jahr int NULL,
  Abschnitt int NULL,
  Fach_ID int NULL,
  Lehrer_ID int NULL,
  DatumAenderungSchild smalldatetime NULL,
  DatumAenderungSchildWeb smalldatetime NULL,
  Kurs varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Inhaltl_Prozessbez_Komp text COLLATE Latin1_General_CI_AS NULL,
  Methodische_Komp text COLLATE Latin1_General_CI_AS NULL,
  Lern_Arbeitsverhalten text COLLATE Latin1_General_CI_AS NULL,
  Massn_Inhaltl_Prozessbez_Komp text COLLATE Latin1_General_CI_AS NULL,
  Massn_Methodische_Komp text COLLATE Latin1_General_CI_AS NULL,
  Massn_Lern_Arbeitsverhalten text COLLATE Latin1_General_CI_AS NULL,
  Verantwortlichkeit_Eltern text COLLATE Latin1_General_CI_AS NULL,
  Verantwortlichkeit_Schueler text COLLATE Latin1_General_CI_AS NULL,
  Zeitrahmen_von_Datum smalldatetime NULL,
  Zeitrahmen_bis_Datum smalldatetime NULL,
  Ueberpruefung_Datum smalldatetime NULL,
  Naechstes_Beratungsgespraech smalldatetime NULL,
  Leistung_ID int NULL,
  Kurs_ID int NULL,
  EingabeFertig varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Faecher varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Abgeschlossen varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Bemerkungen text COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerFoerderempfehlungen_PK PRIMARY KEY CLUSTERED (GU_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerFotos : 
--

CREATE TABLE dbo.SchuelerFotos (
  Schueler_ID int NOT NULL,
  Foto image NULL,
  SchulnrEigner int NULL,
  FotoBase64 ntext COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerFotos_PK PRIMARY KEY CLUSTERED (Schueler_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerGSDaten : 
--

CREATE TABLE dbo.SchuelerGSDaten (
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Note_Sprachgebrauch int NULL,
  Note_Lesen int NULL,
  Note_Rechtschreiben int NULL,
  Note_Sachunterricht int NULL,
  Note_Mathematik int NULL,
  Note_Englisch int NULL,
  Note_KunstTextil int NULL,
  Note_Musik int NULL,
  Note_Sport int NULL,
  Note_Religion int NULL,
  Durchschnittsnote_Sprache float NULL,
  Durchschnittsnote_Einfach float NULL,
  Durchschnittsnote_Gewichtet float NULL,
  Anrede_Klassenlehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Nachname_Klassenlehrer varchar(50) COLLATE Latin1_General_CI_AS NULL,
  GS_Klasse varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Bemerkungen text COLLATE Latin1_General_CI_AS NULL,
  Geschwisterkind varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT SchuelerGSDaten_PK PRIMARY KEY CLUSTERED (Schueler_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerKAoADaten : 
--

CREATE TABLE dbo.SchuelerKAoADaten (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Jahr int NOT NULL,
  Abschnitt int NOT NULL,
  Jahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Kategorie varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Merkmal varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Zusatzmerkmal varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Anschlussoption varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Berufsfeld varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  KategorieID int NULL,
  MerkmalID int NULL,
  ZusatzmerkmalID int NULL,
  AnschlussoptionID int NULL,
  BerufsfeldID int NULL,
  CONSTRAINT SchuelerKAoADaten_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerLD_PSFachBem : 
--

CREATE TABLE dbo.SchuelerLD_PSFachBem (
  ID int NOT NULL,
  Abschnitt_ID int NOT NULL,
  ASV ntext COLLATE Latin1_General_CI_AS NULL,
  LELS ntext COLLATE Latin1_General_CI_AS NULL,
  ESF ntext COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  BemerkungFSP ntext COLLATE Latin1_General_CI_AS NULL,
  BemerkungVersetzung ntext COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig_ASV nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig_LELS nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig_ESF nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig_VERS nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig_FSP nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerLD_PSFachBem_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerLeistungsdaten : 
--

CREATE TABLE dbo.SchuelerLeistungsdaten (
  ID int NOT NULL,
  Abschnitt_ID int NOT NULL,
  Fach_ID int NOT NULL,
  Hochrechnung int NULL,
  FachLehrer varchar(10) COLLATE Latin1_General_CI_AS NULL,
  Kursart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  Kurs_ID int NULL,
  NotenKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Warnung varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Warndatum smalldatetime NULL,
  AbiFach varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Wochenstunden smallint NULL,
  AbiZeugnis varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Prognose varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Fehlstd smallint NULL,
  uFehlstd smallint NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Lernentw ntext COLLATE Latin1_General_CI_AS NULL,
  Gekoppelt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  VorherAbgeschl varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  AbschlussJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HochrechnungStatus varchar(1) COLLATE Latin1_General_CI_AS NULL,
  SchulNr int NULL,
  Zusatzkraft varchar(10) COLLATE Latin1_General_CI_AS NULL,
  WochenstdZusatzkraft int NULL,
  Prf10Fach varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AufZeugnis varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Gewichtung int DEFAULT 1 NULL,
  SchulnrEigner int NULL,
  NoteAbschlussBA varchar(2) COLLATE Latin1_General_CI_AS NULL,
  EingabeFertig nvarchar(1) COLLATE Latin1_General_CI_AS NULL,
  Umfang varchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerLeistungsdaten_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerListe : 
--

CREATE TABLE dbo.SchuelerListe (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Erzeuger varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Privat varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerListe_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerListe_Inhalt : 
--

CREATE TABLE dbo.SchuelerListe_Inhalt (
  Liste_ID int NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerListeInhalt_PK PRIMARY KEY CLUSTERED (Liste_ID, Schueler_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerMerkmale : 
--

CREATE TABLE dbo.SchuelerMerkmale (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Kurztext varchar(10) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  DatumVon smalldatetime NULL,
  DatumBis smalldatetime NULL
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerNUESDaten : 
--

CREATE TABLE dbo.SchuelerNUESDaten (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Jahr int NOT NULL,
  Abschnitt int NOT NULL,
  JahrgangIst varchar(2) COLLATE Latin1_General_CI_AS NULL,
  HauptMerkmal varchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  NebenMerkmal varchar(20) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerNUESDaten_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerReportvorlagen : 
--

CREATE TABLE dbo.SchuelerReportvorlagen (
  User_ID int NOT NULL,
  SchulnrEigner int NULL,
  ReportVorlage varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Schueler_IDs ntext COLLATE Latin1_General_CI_AS NULL
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerSprachenfolge : 
--

CREATE TABLE dbo.SchuelerSprachenfolge (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  Fach_ID int NOT NULL,
  JahrgangVon smallint NULL,
  JahrgangBis smallint NULL,
  Reihenfolge varchar(1) COLLATE Latin1_General_CI_AS NULL,
  AbschnittVon smallint NULL,
  AbschnittBis smallint NULL,
  SchulnrEigner int NULL,
  Referenzniveau varchar(5) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerSprachenfolge_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerTelefone : 
--

CREATE TABLE dbo.SchuelerTelefone (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  TelefonArt_ID int NULL,
  Telefonnummer varchar(20) COLLATE Latin1_General_CI_AS NULL,
  Bemerkung varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Sortierung int DEFAULT 32000 NULL,
  SchulnrEigner int NULL,
  Gesperrt varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  CONSTRAINT SchuelerTelefone_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerVermerke : 
--

CREATE TABLE dbo.SchuelerVermerke (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  VermerkArt_ID int NULL,
  Datum smalldatetime NULL,
  Bemerkung ntext COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  AngelegtVon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  GeaendertVon varchar(20) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerVermerke_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table SchuelerWiedervorlage : 
--

CREATE TABLE dbo.SchuelerWiedervorlage (
  ID int NOT NULL,
  Schueler_ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Bemerkung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  AngelegtAm smalldatetime NULL,
  WiedervorlageAm smalldatetime NULL,
  ErledigtAm smalldatetime NULL,
  User_ID int NULL,
  Sekretariat varchar(1) COLLATE Latin1_General_CI_AS NULL,
  Typ varchar(1) COLLATE Latin1_General_CI_AS NULL,
  NichtLoeschen varchar(1) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT SchuelerWiedervorlage_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table SchuelerZuweisungen : 
--

CREATE TABLE dbo.SchuelerZuweisungen (
  Abschnitt_ID int NOT NULL,
  Fach_ID int NOT NULL,
  Kursart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  CONSTRAINT SchuelerZuweisungen_PK PRIMARY KEY CLUSTERED (Abschnitt_ID, Fach_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Stundentafel : 
--

CREATE TABLE dbo.Stundentafel (
  ID int NOT NULL,
  Bezeichnung varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Jahrgang_ID int NULL,
  ASDJahrgang varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Klasse varchar(15) COLLATE Latin1_General_CI_AS NULL,
  SGL varchar(3) COLLATE Latin1_General_CI_AS NULL,
  Fachklasse_ID int NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  SchulnrEigner int NULL,
  Sortierung int DEFAULT 32000 NULL,
  CONSTRAINT Stundentafel_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Stundentafel_Faecher : 
--

CREATE TABLE dbo.Stundentafel_Faecher (
  ID int NOT NULL,
  Stundentafel_ID int NOT NULL,
  Fach_ID int NOT NULL,
  KursartAllg varchar(5) COLLATE Latin1_General_CI_AS NULL,
  WochenStd smallint NULL,
  LehrerKrz varchar(10) COLLATE Latin1_General_CI_AS NULL,
  EpochenUnterricht varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '-' NULL,
  Sortierung smallint DEFAULT 32000 NULL,
  Sichtbar varchar(1) COLLATE Latin1_General_CI_AS DEFAULT '+' NULL,
  Gewichtung int DEFAULT 1 NULL,
  SchulnrEigner int NULL,
  CONSTRAINT Stundentafel_Faecher_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table TextExportVorlagen : 
--

CREATE TABLE dbo.TextExportVorlagen (
  SchulnrEigner int NOT NULL,
  VorlageName varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  Daten text COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT TextExportVorlagen_PK PRIMARY KEY CLUSTERED (SchulnrEigner, VorlageName)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table Usergroups : 
--

CREATE TABLE dbo.Usergroups (
  UG_ID int NOT NULL,
  UG_Bezeichnung varchar(64) COLLATE Latin1_General_CI_AS NULL,
  UG_Kompetenzen varchar(255) COLLATE Latin1_General_CI_AS NULL,
  UG_Nr int NULL,
  SchulnrEigner int NULL,
  CONSTRAINT Usergroups_PK PRIMARY KEY CLUSTERED (UG_ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Definition for table Users : 
--

CREATE TABLE dbo.Users (
  ID int NOT NULL,
  US_Name varchar(50) COLLATE Latin1_General_CI_AS NOT NULL,
  US_LoginName varchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  US_Password varchar(20) COLLATE Latin1_General_CI_AS NULL,
  US_UserGroups varchar(50) COLLATE Latin1_General_CI_AS NULL,
  US_Privileges varchar(255) COLLATE Latin1_General_CI_AS NULL,
  SchulnrEigner int NULL,
  EMail varchar(100) COLLATE Latin1_General_CI_AS NULL,
  EMailName varchar(100) COLLATE Latin1_General_CI_AS NULL,
  SMTPUsername varchar(100) COLLATE Latin1_General_CI_AS NULL,
  SMTPPassword varchar(100) COLLATE Latin1_General_CI_AS NULL,
  EMailSignature text COLLATE Latin1_General_CI_AS NULL,
  HeartbeatDate int NULL,
  ComputerName varchar(50) COLLATE Latin1_General_CI_AS NULL,
  US_PasswordHash varchar(255) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT Users_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

--
-- Definition for table ZuordnungReportvorlagen : 
--

CREATE TABLE dbo.ZuordnungReportvorlagen (
  ID int NOT NULL,
  SchulnrEigner int NOT NULL,
  Jahrgang_ID int NOT NULL,
  Abschluss varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AbschlussBB varchar(50) COLLATE Latin1_General_CI_AS NULL,
  AbschlussArt int NULL,
  VersetzungKrz varchar(2) COLLATE Latin1_General_CI_AS NULL,
  Fachklasse_ID int NULL,
  Reportvorlage varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Beschreibung varchar(255) COLLATE Latin1_General_CI_AS NULL,
  Gruppe varchar(50) COLLATE Latin1_General_CI_AS NULL,
  Zeugnisart varchar(5) COLLATE Latin1_General_CI_AS NULL,
  CONSTRAINT ZuordnungReportvorlagen_PK PRIMARY KEY CLUSTERED (ID)
    WITH (
      PAD_INDEX = OFF, IGNORE_DUP_KEY = OFF, STATISTICS_NORECOMPUTE = OFF,
      ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
ON [PRIMARY]
GO

--
-- Data for table dbo.Kompetenzen  (LIMIT 0,500)
--

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (11, 100, N'Ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (12, 100, N'Ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (13, 100, N'Löschen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (14, 100, N'Vermerke ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (15, 100, N'KAoA-Daten ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (21, 200, N'Ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (22, 200, N'Funktionsbezogen ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (23, 200, N'Alle ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (31, 300, N'Alle Formulare drucken')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (32, 300, N'Standard-Formulare drucken')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (33, 300, N'Ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (34, 300, N'Löschen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (41, 400, N'Daten importieren')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (42, 400, N'Schülerdaten exportieren')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (43, 400, N'Lehrerdaten exportieren')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (61, 600, N'Ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (62, 600, N'Ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (71, 700, N'Backup durchführen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (72, 700, N'Gelöschte Daten zurückholen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (73, 700, N'Farben für Fächergruppen ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (74, 700, N'Daten aus Kurs42 importieren')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (81, 800, N'Ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (82, 800, N'Ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (83, 800, N'Löschen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (91, 900, N'Ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (92, 900, N'Ändern')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (93, 900, N'Löschen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (94, 900, N'Detaildaten ansehen')
GO

INSERT INTO dbo.Kompetenzen (KO_ID, KO_Gruppe, KO_Bezeichnung)
VALUES 
  (95, 900, N'Detaildaten ändern')
GO

--
-- Data for table dbo.Kompetenzgruppen  (LIMIT 0,500)
--

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (1, 1, 100, N'Schüler-Individualdaten')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (1, 2, 200, N'Schüler-Leistungsdaten')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (1, 3, 800, N'Katalog-Einträge')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (2, 1, 300, N'Berichte')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (2, 2, 900, N'Lehrerdaten')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (3, 1, 400, N'Import/Export')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (3, 2, 500, N'Blockoperationen')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (3, 3, 600, N'Schulbezogene Daten')
GO

INSERT INTO dbo.Kompetenzgruppen (KG_Spalte, KG_Zeile, KG_ID, KG_Bezeichnung)
VALUES 
  (3, 4, 700, N'Extras')
GO

--
-- Data for table dbo.Usergroups  (LIMIT 0,500)
--

INSERT INTO dbo.Usergroups (UG_ID, UG_Bezeichnung, UG_Kompetenzen, UG_Nr, SchulnrEigner)
VALUES 
  (1, N'Administrator', N'$', 1, 0)
GO

INSERT INTO dbo.Usergroups (UG_ID, UG_Bezeichnung, UG_Kompetenzen, UG_Nr, SchulnrEigner)
VALUES 
  (2, N'Schulleitung', N'11;12;13;21;22;23;31;32;33;41;42;61;62;71;72;73;81;82;83', 2, 0)
GO

INSERT INTO dbo.Usergroups (UG_ID, UG_Bezeichnung, UG_Kompetenzen, UG_Nr, SchulnrEigner)
VALUES 
  (3, N'Lehrer', N'11;21;22;81;31;61', 3, 0)
GO

INSERT INTO dbo.Usergroups (UG_ID, UG_Bezeichnung, UG_Kompetenzen, UG_Nr, SchulnrEigner)
VALUES 
  (4, N'Sekretariat', N'11;12;13;81;82;83;31;61;71', 4, 0)
GO

--
-- Data for table dbo.Users  (LIMIT 0,500)
--

INSERT INTO dbo.Users (ID, US_Name, US_LoginName, US_Password, US_UserGroups, US_Privileges, SchulnrEigner, EMail, EMailName, SMTPUsername, SMTPPassword, EMailSignature, HeartbeatDate, ComputerName, US_PasswordHash)
VALUES 
  (1, N'Administrator', N'Admin', NULL, N'1;2;3;4', N'$', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO

--
-- Definition for indices : 
--

CREATE UNIQUE NONCLUSTERED INDEX K_Adressart_IDX1 ON dbo.K_Adressart
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Lehrer_IDX1 ON dbo.K_Lehrer
  (Kuerzel)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Versetzung_IDX1 ON dbo.Versetzung
  (Klasse)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Fachklassen_IDX1 ON dbo.EigeneSchule_Fachklassen
  (BKIndexTyp, FKS, AP)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Faecher_IDX1 ON dbo.EigeneSchule_Faecher
  (FachKrz)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Jahrgaenge_IDX1 ON dbo.EigeneSchule_Jahrgaenge
  (InternKrz)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Kursart_IDX1 ON dbo.EigeneSchule_Kursart
  (Kursart, KursartAllg)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_KursartAllg_IDX1 ON dbo.EigeneSchule_KursartAllg
  (KursartAllg)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Schulformen_IDX1 ON dbo.EigeneSchule_Schulformen
  (SGL)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX EigeneSchule_Zertifikate_IX1 ON dbo.EigeneSchule_Zertifikate
  (SchulnrEigner, Kuerzel)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Schwerpunkt_IDX1 ON dbo.K_Schwerpunkt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_BeschaeftigungsArt_IDX1 ON dbo.K_BeschaeftigungsArt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_EinschulungsArt_IDX1 ON dbo.K_EinschulungsArt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_EntlassGrund_IDX1 ON dbo.K_EntlassGrund
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_ErzieherArt_IDX1 ON dbo.K_ErzieherArt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_ErzieherFunktion_IDX1 ON dbo.K_ErzieherFunktion
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_FahrschuelerArt_IDX1 ON dbo.K_FahrschuelerArt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Foerderschwerpunkt_IDX1 ON dbo.K_Foerderschwerpunkt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Haltestelle_IDX1 ON dbo.K_Haltestelle
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Ort_IDX1 ON dbo.K_Ort
  (PLZ)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Ortsteil_IDX1 ON dbo.K_Ortsteil
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Religion_IDX1 ON dbo.K_Religion
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Schule_IDX1 ON dbo.K_Schule
  (SchulNr)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Sportbefreiung_IDX1 ON dbo.K_Sportbefreiung
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Staat_IDX1 ON dbo.K_Staat
  (StatistikKrz)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_TelefonArt_IDX1 ON dbo.K_TelefonArt
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX K_Vermerkart_IDX1 ON dbo.K_Vermerkart
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Kurse_IDX1 ON dbo.Kurse
  (Jahr, Abschnitt, KurzBez, Fach_ID, ASDJahrgang, Jahrgaenge, KursartAllg, Wochenstd, LehrerKrz)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchildFilter_IDX1 ON dbo.SchildFilter
  (Name)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Schueler_IDX1 ON dbo.Schueler
  (GU_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX Schueler_AllgAdr_IDX1 ON dbo.Schueler_AllgAdr
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerAbgaenge_IDX1 ON dbo.SchuelerAbgaenge
  (Schueler_ID, LSSchulEntlassDatum)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerAbitur_IDX1 ON dbo.SchuelerAbitur
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerEinzelleistungen_idx_3 ON dbo.SchuelerEinzelleistungen
  (Leistung_ID, Art_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerEinzelleistungen_idx_4 ON dbo.SchuelerEinzelleistungen
  (SchulnrEigner)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerErzAdr_IDX1 ON dbo.SchuelerErzAdr
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerLernabschnittsdaten_IDX1 ON dbo.SchuelerLernabschnittsdaten
  (Schueler_ID, Jahr, Abschnitt, Bildungsgang, WechselNr)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX ix_SchuelerFehlstunden_GUID ON dbo.SchuelerFehlstunden
  (GU_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerFHR_IDX1 ON dbo.SchuelerFHR
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerFoema_ix_1 ON dbo.SchuelerFoerderempfehlungen
  (Schueler_ID, Jahr, Abschnitt, DatumAngelegt)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerLeistungsdaten_IDX2 ON dbo.SchuelerLeistungsdaten
  (Abschnitt_ID, Fach_ID, Kursart, Kurs_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerLeistungsdaten_Kurs_IDX ON dbo.SchuelerLeistungsdaten
  (Kurs_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerListe_IDX1 ON dbo.SchuelerListe
  (Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX SchuelerSprachenfolge_IDX1 ON dbo.SchuelerSprachenfolge
  (Schueler_ID, Fach_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerTelefone_IDX1 ON dbo.SchuelerTelefone
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX SchuelerVermerke_IDX1 ON dbo.SchuelerVermerke
  (Schueler_ID)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Stundentafel_Faecher_IDX1 ON dbo.Stundentafel_Faecher
  (Stundentafel_ID, Fach_ID)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Usergroups_IX1 ON dbo.Usergroups
  (UG_Bezeichnung)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE UNIQUE NONCLUSTERED INDEX Users_IX1 ON dbo.Users
  (US_LoginName)
WITH (
  PAD_INDEX = OFF,
  IGNORE_DUP_KEY = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for foreign keys : 
--

ALTER TABLE dbo.K_AllgAdresse
ADD CONSTRAINT K_AllgAdresse_AdressArt_FK FOREIGN KEY (AllgAdrAdressArt) 
  REFERENCES dbo.K_Adressart (Bezeichnung) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.AllgAdrAnsprechpartner
ADD CONSTRAINT Ansprechpartner_Adr_FK FOREIGN KEY (Adresse_ID) 
  REFERENCES dbo.K_AllgAdresse (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.EigeneSchule_Abteilungen
ADD CONSTRAINT EigeneSchule_Abteilungen_Leiter_FK FOREIGN KEY (AbteilungsLeiter) 
  REFERENCES dbo.K_Lehrer (Kuerzel) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Versetzung
ADD CONSTRAINT Versetzung_Lehrer_FK FOREIGN KEY (KlassenlehrerKrz) 
  REFERENCES dbo.K_Lehrer (Kuerzel) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.EigeneSchule_Abt_Kl
ADD CONSTRAINT EigeneSchuleAbtKl_Abteilung_FK FOREIGN KEY (Abteilung_ID) 
  REFERENCES dbo.EigeneSchule_Abteilungen (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.EigeneSchule_Abt_Kl
ADD CONSTRAINT EigeneSchuleAbtKl_Klasse_FK FOREIGN KEY (Klasse) 
  REFERENCES dbo.Versetzung (Klasse) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.EigeneSchule_FachTeilleistungen
ADD CONSTRAINT EigeneSchule_FachTeilleistungen_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.Fachklassen_Schwerpunkte
ADD CONSTRAINT Fachklassen_Schwerpunkte_Fachkl_FK FOREIGN KEY (Fachklasse_ID) 
  REFERENCES dbo.EigeneSchule_Fachklassen (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Fachklassen_Schwerpunkte
ADD CONSTRAINT Fachklassen_Schwerpunkte_Schwerp_FK FOREIGN KEY (Schwerpunkt_ID) 
  REFERENCES dbo.K_Schwerpunkt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.KursLehrer
ADD CONSTRAINT KursLehrer_Kurs_FK FOREIGN KEY (Kurs_ID) 
  REFERENCES dbo.Kurse (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.KursLehrer
ADD CONSTRAINT KursLehrer_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Lehrer_IMEI
ADD CONSTRAINT Lehrer_IMEI_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.LehrerAbschnittsdaten
ADD CONSTRAINT LehrerAbschnitte_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerAnrechnung
ADD CONSTRAINT LehrerAnrechnung_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerEntlastung
ADD CONSTRAINT LehrerEntlastung_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerFunktionen
ADD CONSTRAINT LehrerFunktionen_Funktion_FK FOREIGN KEY (Funktion_ID) 
  REFERENCES dbo.K_Schulfunktionen (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerFunktionen
ADD CONSTRAINT LehrerFunktionen_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerLehramt
ADD CONSTRAINT LehrerLehramt_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.LehrerMehrleistung
ADD CONSTRAINT LehrerMehrleistung_Lehrer_FK FOREIGN KEY (Lehrer_ID) 
  REFERENCES dbo.K_Lehrer (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Einschulungsart_FK FOREIGN KEY (Einschulungsart_ID) 
  REFERENCES dbo.K_EinschulungsArt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Fahrschueler_FK FOREIGN KEY (Fahrschueler_ID) 
  REFERENCES dbo.K_FahrschuelerArt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Foerderschwerpunkt_FK FOREIGN KEY (Foerderschwerpunkt_ID) 
  REFERENCES dbo.K_Foerderschwerpunkt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Haltestelle_FK FOREIGN KEY (Haltestelle_ID) 
  REFERENCES dbo.K_Haltestelle (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Ort_FK FOREIGN KEY (PLZ) 
  REFERENCES dbo.K_Ort (PLZ) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Ortsteil_FK FOREIGN KEY (Ortsteil_ID) 
  REFERENCES dbo.K_Ortsteil (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Religion_FK FOREIGN KEY (Religion_ID) 
  REFERENCES dbo.K_Religion (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Sportbefreiung_FK FOREIGN KEY (Sportbefreiung_ID) 
  REFERENCES dbo.K_Sportbefreiung (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Staat_FK FOREIGN KEY (StaatKrz) 
  REFERENCES dbo.K_Staat (StatistikKrz) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler
ADD CONSTRAINT Schueler_Versetzung_FK FOREIGN KEY (Klasse) 
  REFERENCES dbo.Versetzung (Klasse) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler_AllgAdr
ADD CONSTRAINT SchuelerAllgAdr_Adresse_FK FOREIGN KEY (Adresse_ID) 
  REFERENCES dbo.K_AllgAdresse (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler_AllgAdr
ADD CONSTRAINT SchuelerAllgAdr_Ansprech_FK FOREIGN KEY (Ansprechpartner_ID) 
  REFERENCES dbo.AllgAdrAnsprechpartner (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler_AllgAdr
ADD CONSTRAINT SchuelerAllgAdr_Beschaeftigungsart_FK FOREIGN KEY (Vertragsart_ID) 
  REFERENCES dbo.K_BeschaeftigungsArt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Schueler_AllgAdr
ADD CONSTRAINT SchuelerAllgAdr_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerAbgaenge
ADD CONSTRAINT SchuelerAbgaenge_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerAbiFaecher
ADD CONSTRAINT SchuelerAbiFaecher_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerAbiFaecher
ADD CONSTRAINT SchuelerAbiFaecher_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerAbitur
ADD CONSTRAINT SchuelerAbitur_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerAnkreuzfloskeln
ADD CONSTRAINT SchuelerAKF_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerBKAbschluss
ADD CONSTRAINT SchuelerBKAbschl_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerBKFaecher
ADD CONSTRAINT SchuelerBKFaecher_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerBKFaecher
ADD CONSTRAINT SchuelerBKFaecher_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerDatenschutz
ADD CONSTRAINT SchuelerDatenschutz_FK2 FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerEinzelleistungen
ADD CONSTRAINT SchuelerEL_Art_FK FOREIGN KEY (Art_ID) 
  REFERENCES dbo.K_Einzelleistungen (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerErzAdr
ADD CONSTRAINT SchuelerErzAdr_ErzieherArt_FK FOREIGN KEY (ErzieherArt_ID) 
  REFERENCES dbo.K_ErzieherArt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerErzAdr
ADD CONSTRAINT SchuelerErzAdr_Ort_FK FOREIGN KEY (ErzPLZ) 
  REFERENCES dbo.K_Ort (PLZ) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerErzAdr
ADD CONSTRAINT SchuelerErzAdr_Ortsteil_FK FOREIGN KEY (ErzOrtsteil_ID) 
  REFERENCES dbo.K_Ortsteil (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerErzAdr
ADD CONSTRAINT SchuelerErzAdr_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerErzFunktion
ADD CONSTRAINT SchuelerErzFunktion_Erzieher_FK FOREIGN KEY (Erzieher_ID) 
  REFERENCES dbo.SchuelerErzAdr (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerErzFunktion
ADD CONSTRAINT SchuelerErzFunktion_Funktion_FK FOREIGN KEY (Funktion_ID) 
  REFERENCES dbo.K_ErzieherFunktion (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLernabschnittsdaten
ADD CONSTRAINT SchuelerLernabschnittsdaten_Fachklasse_FK FOREIGN KEY (Fachklasse_ID) 
  REFERENCES dbo.EigeneSchule_Fachklassen (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLernabschnittsdaten
ADD CONSTRAINT SchuelerLernabschnittsdaten_Foerderschwerpunkt_FK FOREIGN KEY (Foerderschwerpunkt_ID) 
  REFERENCES dbo.K_Foerderschwerpunkt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLernabschnittsdaten
ADD CONSTRAINT SchuelerLernabschnittsdaten_Jahrgang_FK FOREIGN KEY (Jahrgang_ID) 
  REFERENCES dbo.EigeneSchule_Jahrgaenge (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLernabschnittsdaten
ADD CONSTRAINT SchuelerLernabschnittsdaten_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerFehlstunden
ADD CONSTRAINT SchuelerFehlstunden_Abschnitt_FK FOREIGN KEY (Abschnitt_ID) 
  REFERENCES dbo.SchuelerLernabschnittsdaten (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerFHR
ADD CONSTRAINT SchuelerFHR_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerFHRFaecher
ADD CONSTRAINT SchuelerFHRFaecher_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerFHRFaecher
ADD CONSTRAINT SchuelerFHRFaecher_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerFoerderempfehlungen
ADD CONSTRAINT SchuelerFE_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerFotos
ADD CONSTRAINT SchuelerFotos_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerKAoADaten
ADD CONSTRAINT SchuelerKAoADaten_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerLD_PSFachBem
ADD CONSTRAINT SchuelerLD_PSFachBem_Abschnitt_FK FOREIGN KEY (Abschnitt_ID) 
  REFERENCES dbo.SchuelerLernabschnittsdaten (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLeistungsdaten
ADD CONSTRAINT SchuelerLeistungsdaten_Abschnitt_FK FOREIGN KEY (Abschnitt_ID) 
  REFERENCES dbo.SchuelerLernabschnittsdaten (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLeistungsdaten
ADD CONSTRAINT SchuelerLeistungsdaten_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerLeistungsdaten
ADD CONSTRAINT SchuelerLeistungsdaten_Kurs_FK FOREIGN KEY (Kurs_ID) 
  REFERENCES dbo.Kurse (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerListe_Inhalt
ADD CONSTRAINT SchuelerListeInhalt_Liste_FK FOREIGN KEY (Liste_ID) 
  REFERENCES dbo.SchuelerListe (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerListe_Inhalt
ADD CONSTRAINT SchuelerListeInhalt_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerMerkmale
ADD CONSTRAINT SchuelerMerkmale_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerNUESDaten
ADD CONSTRAINT SchuelerNUESDaten_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE CASCADE
GO

ALTER TABLE dbo.SchuelerSprachenfolge
ADD CONSTRAINT SchuelerSprachenfolge_Fach_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerSprachenfolge
ADD CONSTRAINT SchuelerSprachenfolge_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerTelefone
ADD CONSTRAINT SchuelerTelefone_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerTelefone
ADD CONSTRAINT SchuelerTelefone_Telefonart_FK FOREIGN KEY (TelefonArt_ID) 
  REFERENCES dbo.K_TelefonArt (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerVermerke
ADD CONSTRAINT SchuelerVermerke_Schueler_FK FOREIGN KEY (Schueler_ID) 
  REFERENCES dbo.Schueler (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerVermerke
ADD CONSTRAINT SchuelerVermerke_VermerkArt_FK FOREIGN KEY (VermerkArt_ID) 
  REFERENCES dbo.K_Vermerkart (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.SchuelerZuweisungen
ADD CONSTRAINT Zuweisungen_Abschnitt_FK FOREIGN KEY (Abschnitt_ID) 
  REFERENCES dbo.SchuelerLernabschnittsdaten (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Stundentafel_Faecher
ADD CONSTRAINT StundentafelFaecher_Faecher_FK FOREIGN KEY (Fach_ID) 
  REFERENCES dbo.EigeneSchule_Faecher (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

ALTER TABLE dbo.Stundentafel_Faecher
ADD CONSTRAINT StundentafelFaecher_Stdtafel_FK FOREIGN KEY (Stundentafel_ID) 
  REFERENCES dbo.Stundentafel (ID) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
GO

